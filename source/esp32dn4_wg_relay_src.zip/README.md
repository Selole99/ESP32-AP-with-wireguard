# ESP32-DN4 · WireGuard 中继固件

把 ESP32 做成一个 **「WiFi 中继 + WireGuard 全局出口」**：手机连上 ESP32 的热点，
所有流量经 NAT 转发进 WireGuard 隧道，从对端出口上网。上游 WiFi 的账号、密码、加密方式，
以及 WireGuard、热点参数，全部在手机浏览器里配置。

```
手机 ──(热点 192.168.4.1, WPA2)── ESP32-AP
                                    │  NAPT (lwIP)
                                    ▼
                            默认路由 = wg 接口  ← 全部流量
                                    │
                                    ├── WireGuard UDP ──(STA)── 上游 WiFi ──> 对端服务器
                                    ▼
                                 互联网
```

---

## 一、功能对照（对应你的 5 条要求）

| 要求 | 实现 | 代码位置 |
|---|---|---|
| 1. 使用 WireGuard，所有流量走 WG | `esp_wireguard_set_default()` 把 lwIP 默认 netif 切到 wg 接口（无分流、全部入隧道）；WG 断开立刻关 NAPT（防泄漏 / kill-switch） | `wg_mgr.c` / `main.c` |
| 2. 从手机/电脑浏览器取时间 | 网页加载即 `POST /api/time`（`Date.now()` + 时区），固件 `settimeofday()` | `index.html` / `time_sync.c` |
| 3. 先有时间再连 WG | 检查链：`wg.enabled → time_sync_ready() → sta_has_ip() → validate() → connect()`；状态机每秒重试，状态 `wait_time` | `wg_mgr.c` / `main.c` |
| 4. 简易 Web 端 | 单页 Web：扫描周边 WiFi、选 SSID/密码/加密方式、WireGuard 全套参数 + `.conf` 粘贴导入、热点 SSID/密码/加密/信道 | `web_server.c` / `index.html` |
| 5. NAT 转发 | `esp_netif_napt_enable(WIFI_AP_DEF)` + `CONFIG_LWIP_IP_FORWARD` / `IPV4_NAPT` | `wifi_mgr.c` / `sdkconfig.defaults` |
| 6. 烧写口 COM9 | `flash.ps1`（默认 `-Port COM9`，即电脑上识别到的 ESP32 串口） | `flash.ps1` |

额外做了：强制门户跳转（连上热点自动弹配置页）、`.conf` 一键解析、DNS 随 DHCP 下发、
上游 IP 变化自动重建隧道、WPA3/PMF、MTU 可调。

---

## 二、编译与烧写（Windows）

前置：已安装 **ESP-IDF v5.x**（v5.0 ~ v5.4 均可），Python 环境正常。

支持两种芯片（代码不区分，只是 bootloader 偏移和 flash 频率不同）：

| 芯片 | set-target | bootloader 地址 | 建议 flash 参数 |
|---|---|---|---|
| ESP32 / ESP32-D0WD | `idf.py set-target esp32` | `0x1000` | `--flash_mode dio --flash_size 4MB --flash_freq 40m` |
| ESP32-S3（USB-JTAG 板） | `idf.py set-target esp32s3` | `0x0` | `--flash_mode dio --flash_size 4MB --flash_freq 80m` |

S3 用板载 USB 时，`sdkconfig.defaults` 里的 `CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG=y` 打开着
（日志从 USB 口出来）；换回 CP210x 的普通 ESP32 时把那两行注释掉，日志走 UART0。

```powershell
cd esp32dn4_wg_relay

# 1) 编译（首次会自动 set-target esp32，并从组件注册表拉取 esp_wireguard）
.\build.ps1

# 2) 烧到 COM9（默认端口就是 COM9）
.\flash.ps1

# 3) 需要看串口日志
.\flash.ps1 -Monitor

# 其它
.\build.ps1 -Clean                     # 全清重编
.\flash.ps1 -Erase                     # 全片擦除（清空配置）
.\build.ps1 -IdfPath C:\Espressif\frameworks\esp-idf-v5.3.2
```

脚本会自动探测 `C:\Espressif\frameworks\esp-idf-*`、`C:\esp\esp-idf`、`%USERPROFILE%\esp\esp-idf`，
也可以用 `-IdfPath` 指定。若你习惯自己开 ESP-IDF 的 PowerShell，直接：

```powershell
idf.py set-target esp32
idf.py -p COM9 build flash monitor
```

### 烧写口 = COM9（电脑上的 USB-串口）

已在你的机器上确认：`COM9` = **Silicon Labs CP210x USB to UART Bridge**，就是 ESP32-DN4 的板载串口，
脚本默认值已设为 `COM9`，一般直接 `.\flash.ps1` 就行。换机器/换 USB 口后编号会变，先查：

```powershell
.\tools\list_ports.ps1        # 列出所有串口及描述
.\flash.ps1 -Port COM5        # 手动指定
```

**烧不进时（实测这块板子会遇到）**

症状 A：`Wrong boot mode detected (0x13)` / `Failed to connect`，串口还在刷 `boot:0x13 (SPI_FAST_FLASH_BOOT)`
→ 说明 IO0 在复位那一刻是高电平，板上的 BOOT 键没生效。做法（按可靠度排序）：

1. **短接 IO0 到 GND**（镊子/杜邦线）→ 插 USB → 松开。成功标志是**串口完全静默**（进了下载模式）。
2. 按住 BOOT 的同时**拔插 USB**（不是按 RST），保持按住 1 秒再松。
3. 按键接触不良时反复多按几次。

症状 B：写入报 `Hash of data verified`，但启动时
`E esp_image: invalid segment length 0xffffffff` + `Factory app partition is not bootable`
→ 长距离单次写 827KB 在 CP210x 上会**尾部丢包**。改用分块回读校验的方式（本仓库自带）：

```powershell
python toolslash_verify.py COM9 460800 2400   # 端口 波特率 等下载模式的秒数
```

它会把 app 切成 64KB 块，**每块写完立刻 read_flash 逐字节比对**，不一致的块单独重写，全部通过才复位启动。
想更快也可 `-b 921600`，但链路差时 115200 最稳。

**如果 build 时下载不到 esp_wireguard（网络不通）**

```powershell
.\tools\fetch_deps.ps1 -Vendor     # 克隆到 components/esp_wireguard 并改用本地组件
.\build.ps1
```

此时若报 `wireguard.h: No such file`，把 `esp_wireguard` 加进 `main/CMakeLists.txt` 的 `REQUIRES`。

### 完全没有网络时（只想先验证硬件/网页）

把 `main/idf_component.yml` 里的 `trombik/esp_wireguard` 两项注释掉再编译：
`wg_mgr.c` 会用 `__has_include` 自动降级成 stub（网页可开、能中继、能扫描，
状态页会提示 `wireguard component missing`）。等网络恢复后取消注释即可启用真隧道。

### 组件版本说明（重要）

本固件针对 `trombik/esp_wireguard` **≥ 0.10**（`wireguard_config_t` / `wireguard_ctx_t` 命名）。
如果你的版本更老：

* 编译报 `unknown type name 'wireguard_config_t'` → 在 `main/CMakeLists.txt` 加
  `add_compile_definitions(RELAY_WG_LEGACY_API)`（会改用 `wg_config_t` / `wg_ctx_t`）。
* 编译报 `esp_wireguard_free` 未声明 → 加 `add_compile_definitions(RELAY_WG_NO_FREE)`。

---

## 三、首次使用流程

1. 烧写后，手机搜热点 **`ESP32-RELAY`**，密码 **`relay12345`**（默认，`192.168.4.1`）。
2. 连上后浏览器打开 `http://192.168.4.1/`（多数手机会自动弹出；没有就手动输入）。
   > 页面一打开就会把**手机时间**推给 ESP32，顶部“时间 ✔”变绿。这就是第 2、3 条要求的入口。
3. 进 **中继 WiFi** → 「开始扫描」→ 点你的上游 WiFi → 自动填 SSID，手选加密方式 → 填密码 → **保存并重启**。
4. 重连热点后进 **WireGuard**：粘贴你的 `wg.conf` 点「解析并填入」，或手填
   `PrivateKey / PublicKey / Endpoint / PresharedKey`，保持 `AllowedIP=0.0.0.0`、掩码 `0.0.0.0`（= `/0` 全部流量）
   → **保存并应用**。
5. 回 **状态** 页：`WG 已连接` + `NAT ✔` 即成功；此时客户端流量已全部在隧道里。
6. 想改热点名/密码/加密方式 → **热点** 页 → 保存并重启。

状态机顺序（串口日志会依次出现）：
`wait_time` → （页面推时间）→ `wait_link` → `connecting` → `up` → `NAT forwarding ENABLED`。

---

## 四、服务端要配合的两件事（否则能连上但不通）

设备在隧道内的地址 = 网页里「隧道地址 / 隧道掩码」（默认 `10.66.66.3 / 255.255.255.0`）。
NAT 之后客户端流量的源地址就是它，所以服务端 peer 必须包含它，并且要开转发+出口 NAT：

```ini
[Interface]
Address    = 10.66.66.1/24
ListenPort = 51820
PrivateKey = <服务端私钥>
PostUp   = sysctl -w net.ipv4.ip_forward=1
PostUp   = iptables -t nat -A POSTROUTING -s 10.66.66.0/24 -o eth0 -j MASQUERADE
PostDown = iptables -t nat -D POSTROUTING -s 10.66.66.0/24 -o eth0 -j MASQUERADE

[Peer]
PublicKey    = <ESP32 公钥>
PresharedKey = <可选，与网页里一致>
AllowedIPs   = 10.66.66.3/32
```

* `AllowedIPs` 写设备的隧道地址 `/32`；写 `0.0.0.0/0` 也行（单客户端省事，但会把所有回程路由都吞掉）。
* 网页里「隧道地址」换成别的网段时，服务端 `Address`、`MASQUERADE` 网段、`AllowedIPs` 一起改。
* 云服务器记得放行 UDP `51820`（安全组 / `ufw allow 51820/udp`）。
* 状态页「隧道地址」会实时显示设备真实地址，照它填最稳。

## 五、常见问题

| 现象 | 处理 |
|---|---|
| 一直 `wait_time` | 浏览器没打开过页面。打开 `http://192.168.4.1/` 即自动校时（也可点「用本机时间校准」） |
| `wait_link` | 上游 SSID/密码/加密方式不对。加密方式选错最常见：WPA2/WPA3 混合路由请选 `WPA2/WPA3` 或 `WPA3-SAE` |
| `connecting` 卡住 / 握手 ✗ | 服务端 AllowedIPs 不含设备隧道地址；或上游网络封了 UDP；或 Endpoint 域名解析失败（先把 Endpoint 换成 IP:端口） |
| 连上但网页打不开 | 服务端没开 `ip_forward`/`MASQUERADE`；或 MTU 太大（把 MTU 改 `1280`） |
| 客户端拿到 IP 但 DNS 不解析 | DNS 默认下发 `1.1.1.1 / 8.8.8.8`（走隧道）。被墙就改成隧道内可用的 DNS |
| 想把明文出口彻底掐死 | 现状已满足：NAT 只在 WG `up` 时开启，WG 一掉 NAPT 立即关闭 |
| `wireguard component missing` | 组件没链接进来，见第二节「组件版本说明」 |

---

## 六、目录结构

```
esp32dn4_wg_relay/
├─ CMakeLists.txt          # 工程入口（target=esp32）
├─ sdkconfig.defaults      # NAPT / IP_FORWARD / HTTP / WiFi 缓冲等
├─ partitions.csv          # 1.7MB app 分区（默认 1MB 装不下）
├─ build.ps1 / flash.ps1   # 编译 / 烧写 COM9
├─ tools/
│  ├─ idf.ps1              # 自动探测并载入 ESP-IDF 环境
│  ├─ fetch_deps.ps1       # 依赖拉取 / 离线 vendor
│  ├─ list_ports.ps1       # 列出串口（确认 COM9）
│  ├─ flash_verify.py      # 分块烧写+逐块回读校验（链路不稳时用）
│  ├─ serial_log.py        # 抓串口日志（带复位时序，不依赖 monitor）
│  └─ lint_struct.py       # 静态粗查（括号、声明-实现对照）
└─ main/
   ├─ main.c               # 启动顺序 + 状态机（时间→隧道→NAT）
   ├─ config_store.c/h     # NVS 配置持久化
   ├─ wifi_mgr.c/h         # APSTA、扫描、NAPT、DNS 下发
   ├─ wg_mgr.c/h           # WireGuard 生命周期、默认路由切换、防泄漏
   ├─ time_sync.c/h        # 浏览器时间 / settimeofday / 可选 SNTP 兜底
   ├─ web_server.c/h       # HTTP API（表单编码，无 cJSON 依赖）
   └─ index.html           # 单页配置界面（编译时嵌入固件）
```

## 七、HTTP API（想自己接脚本时用）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/status` | 状态、时间、WG、NAT、隧道地址 |
| GET | `/api/config` | 读取全部配置 |
| GET | `/api/scan` | 扫描周边 WiFi（阻塞 2~3 s） |
| POST | `/api/time` | `epoch_ms`, `tz` → 校时并尝试拉起隧道 |
| POST | `/api/sta` | `ssid`, `password`, `auth` → 保存并重启 |
| POST | `/api/ap` | `ssid`, `password`, `auth`, `channel`, `hidden` → 保存并重启 |
| POST | `/api/wg` | WG 全套参数 → 保存并重连 |
| POST | `/api/wgctl` | `action=up\|down\|restart` |
| POST | `/api/misc` | `action=reboot\|factory` |

请求体统一 `application/x-www-form-urlencoded`。

```powershell
# 例：不开网页，用电脑命令行校时（本机时间）
$ms = [int64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
Invoke-WebRequest -Method POST -Uri http://192.168.4.1/api/time -Body @{epoch_ms=$ms; tz="CST-8"}
```


---

## 八、实测记录（ESP32-S3 rev0.2 / 16MB flash / 8MB PSRAM，COM5）

```
I (221) main: ==== ESP32 WireGuard relay boot ====
I (263) wg: wireguard component: available
I (751) wifi: AP config applied: ssid='ESP32-RELAY' auth=3 ch=6
I (795) wifi:mode : sta (28:84:85:49:17:d0) + softAP (28:84:85:49:17:d1)
I (813) web: http server on :80 (open http://192.168.4.1/)
W (10820) main: waiting for time sync: open http://192.168.4.1/      ← 时间门控
...
I (4836) wg: starting tunnel -> 121.40.114.65:53 (tunnel addr 10.66.66.3/255.255.255.255)
```

状态接口（真机返回）：

```json
{"sta":{"ssid":"DZU_net","connected":true,"has_ip":true,"ip":"172.17.97.215","rssi":-56},
 "ap":{"ssid":"ESP32-RELAY","ip":"192.168.4.1","clients":2},
 "wg":{"state":"up","up":true,"handshake":true,"endpoint":"121.40.114.65:53","tunnel_ip":"10.66.66.3"},
 "time":{"synced":true,"source":"browser","now":"2026-10-30 01:37:15"},
 "napt":true}
```

客户端经隧道出口验证：

```
PC(192.168.4.2) -> ESP32 NAPT -> WG(10.66.66.3) -> 121.40.114.65:53 -> Internet
$ curl --interface 192.168.4.2 http://ip.3322.net
121.40.114.65          ← 服务器公网 IP，证明全部流量都走了 WireGuard
```

设备自身自检（`POST /api/probe`）：

```
{"ok":true,"target":"1.1.1.1:80","err":"ESP_OK","state":"up","handshake":true}
{"ok":true,"target":"223.5.5.5:53","err":"ESP_OK","state":"up","handshake":true}
```

### 实测踩到并已修掉的两个坑（重编时别丢）

1. **`esp_netif` 的 netif 扩展回调会把 `netif->state` 当 `esp_netif_t*`**
   `esp_wireguard` 用 `netif_add(..., state=wireguardif_init_data)` 建隧道接口，
   于是 `esp_netif_internal_dhcpc_cb()` 解引用垃圾指针 → `Guru Meditation (LoadProhibited)`。
   修法：`sdkconfig.defaults` 里 `CONFIG_ESP_NETIF_BRIDGE_EN=y`，
   让 esp_netif 改用 `netif->client_data` 存自己的指针（`lwipopts.h` 里 `LWIP_ESP_NETIF_DATA`）。

2. **表单解析把长 base64 密钥截断**
   URL 编码后 44 字符私钥是 48 字符（`+`→`%2B`、`=`→`%3D`），
   旧 `form_get()` 先拷贝进目标字段再解码，末尾字节被裁掉。
   修法：`web_server.c` 先解码到 512 字节临时缓冲区，再按字段长度拷贝。

### 额外接口

`POST /api/probe`（`ip`、`port`）—— 从隧道发一次 TCP 连接，用来区分
「设备自身出不去（隧道/服务端问题）」和「客户端 NAT 不通」。


---

## 九、MSS 钳制（客户端"WiFi 连上但上不了网"的根因，已修）

现象：手机连着热点、能 ping 通 192.168.4.1，但任何网页都打不开；PC 上用 curl 拿小页面能通、HTTPS 必超时。

原因：隧道 MTU 1280，而客户端按自己 MTU 1500 宣告 MSS≈1460，服务器于是发 1460 字节的段，
进隧道被丢；lwIP 生成的 ICMP "需要分片" 又不带 MTU 字段，客户端不会退回小 MSS，结果是 TLS 卡死。
IDF 的 DHCP 服务器**不支持**下发 MTU 选项（option 26），所以只能自己做 MSS 钳制。

实现：`components/relay_hooks/`（新组件）

```c
/* lwIP 的 ip4_input 钩子：找到客户端 SYN 里的 MSS 选项，改成 隧道MTU-40 = 1240 */
#define LWIP_HOOK_IP4_INPUT(pbuf, netif) relay_ip4_input_hook(pbuf, netif)
```

- 注入方式：`idf_build_set_property(COMPILE_DEFINITIONS
  "ESP_IDF_LWIP_HOOK_FILENAME=\"<绝对路径>/relay_lwip_hooks.h\"" APPEND)`
- 因为 lwip 的静态库引用了这个符号、静态库顺序未必能拉进来，额外加了
  `-Wl,--undefined=relay_ip4_input_hook` 强制保留
- 校验和用 RFC1624 增量更新（**坑**：参与运算的必须是主机序的两个 16 位字，
  传网络序原始值会把校验和算错，导致所有 SYN 被 lwIP 丢弃、HTTP 直接连不上）

实测（修完之后）：

```
HTTPS:  http_code=200  size=2443
2MB  :  http_code=206  size=2000001  speed=343555 B/s
出口IP: 121.40.114.65   ← 服务器 IP
状态  : wg=up handshake=true napt=true
```


---

## 十、发布产物

### 已编译的 bin（`dist/`）

| 文件 | 大小 | 说明 |
|---|---|---|
| `dist/esp32s3_full_4MB.bin` | 878,368 B | **合并镜像（S3），从 0x0 一次刷完，推荐** |
| `dist/app.bin` | 812,832 B | 应用（0x10000） |
| `dist/bootloader.bin` | 21,504 B | 二级引导（S3: 0x0；ESP32: 0x1000） |
| `dist/partition-table.bin` | 3,072 B | 分区表（0x8000） |
| `dist/flash.bat` / `dist/flash.ps1` | — | 一键刷机脚本（默认 COM5） |
| `dist/esp32_classic/` | — | 经典 ESP32 的三个 bin（bootloader 放 0x1000） |

```powershell
cd dist
.lash.ps1 -Port COM5          # 或双击 flash.bat
# 等价的手工命令：
python -m esptool --chip esp32s3 -p COM5 -b 460800 write_flash --flash_mode dio --flash_size 4MB --flash_freq 80m 0x0 esp32s3_full_4MB.bin
```

### 源码合集文档（`docs/`）

| 文件 | 说明 |
|---|---|
| `docs/ESP32-WireGuard-中继固件-源码与说明.md` | 全部源码 + 说明（约 4300 行，Markdown） |
| `docs/ESP32-WireGuard-中继固件-源码与说明.docx` | 同内容的 Word 版 |

重新生成：`python tools/make_doc.py && python tools/make_docx.py`
