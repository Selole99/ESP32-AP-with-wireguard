#!/usr/bin/env python3
"""把 Markdown 源码合集转成 Word（用 office skill 的 python-docx 环境运行）。"""
import pathlib
from docx import Document
from docx.shared import Pt

ROOT = pathlib.Path(__file__).resolve().parent.parent
md = ROOT / "docs" / "ESP32-WireGuard-中继固件-源码与说明.md"
out = ROOT / "docs" / "ESP32-WireGuard-中继固件-源码与说明.docx"

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Microsoft YaHei"
st.font.size = Pt(9.5)

in_code = False
buf = []


def flush():
    global buf
    if not buf:
        return
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.left_indent = Pt(6)
    r = p.add_run("\n".join(buf))
    r.font.name = "Consolas"
    r.font.size = Pt(7.5)
    buf = []


for ln in md.read_text(encoding="utf-8").splitlines():
    if ln.startswith("```"):
        if in_code:
            flush()
            in_code = False
        else:
            in_code = True
        continue
    if in_code:
        buf.append(ln)
        continue
    if ln.startswith("### "):
        doc.add_heading(ln[4:], level=3)
    elif ln.startswith("## "):
        doc.add_heading(ln[3:], level=2)
    elif ln.startswith("# "):
        doc.add_heading(ln[2:], level=1)
    elif ln.startswith("|"):
        p = doc.add_paragraph(ln)
        p.paragraph_format.space_after = Pt(0)
        for r in p.runs:
            r.font.name = "Consolas"
            r.font.size = Pt(7.5)
    elif ln.strip():
        doc.add_paragraph(ln)

flush()
doc.save(out)
print("written:", out, "%.1f KB" % (out.stat().st_size / 1024))
