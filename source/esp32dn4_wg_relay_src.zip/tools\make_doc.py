#!/usr/bin/env python3
"""把工程所有源码汇总成一个 Markdown 文档（避免手抄，保证与代码一致）。"""
import pathlib
import datetime

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "docs" / "ESP32-WireGuard-中继固件-源码与说明.md"

FILES = [
    ("1. 工程根目录", [
        "CMakeLists.txt",
        "partitions.csv",
        "sdkconfig.defaults",
    ]),
    ("2. main 组件（核心逻辑）", [
        "main/CMakeLists.txt",
        "main/idf_component.yml",
        "main/app_config.h",
        "main/main.c",
        "main/config_store.h",
        "main/config_store.c",
        "main/time_sync.h",
        "main/time_sync.c",
        "main/wifi_mgr.h",
        "main/wifi_mgr.c",
        "main/wg_mgr.h",
        "main/wg_mgr.c",
        "main/web_server.h",
        "main/web_server.c",
    ]),
    ("3. Web 界面（编译时嵌入固件）", [
        "main/index.html",
    ]),
    ("4. relay_hooks 组件（lwIP MSS 钳制）", [
        "components/relay_hooks/CMakeLists.txt",
        "components/relay_hooks/relay_lwip_hooks.h",
        "components/relay_hooks/relay_hooks.c",
    ]),
    ("5. 构建 / 烧写脚本", [
        "build.ps1",
        "flash.ps1",
        "tools/idf.ps1",
        "tools/fetch_deps.ps1",
        "tools/list_ports.ps1",
    ]),
    ("6. 调试工具脚本", [
        "tools/serial_log.py",
        "tools/flash_verify.py",
        "tools/diag_flash.py",
        "tools/diag2.py",
        "tools/flash_rom.py",
        "tools/lint_struct.py",
    ]),
]

LANG = {
    ".c": "c", ".h": "c", ".html": "html", ".py": "python",
    ".ps1": "powershell", ".csv": "text", ".txt": "text", ".yml": "yaml",
}


def fence_for(text: str) -> str:
    n = 3
    while "`" * n in text:
        n += 1
    return "`" * n


def emit_header(doc):
    doc.append("# ESP32(-S3) WireGuard 中继固件 · 源码与说明\n")
    doc.append(f"> 生成时间：{datetime.datetime.now():%Y-%m-%d %H:%M}  \n"
               "> 目标芯片：**ESP32-S3**（本机实测 16MB flash / 8MB PSRAM，USB-Serial/JTAG），"
               "代码同样可在经典 ESP32 上编译（只差 bootloader 偏移与 flash 频率）。\n")

    doc.append("""## 0. 一句话说明

把 ESP32 做成「WiFi 中继 + WireGuard 全局出口」：手机连 ESP32 的热点，所有流量经 NAPT 转发进
WireGuard 隧道，从对端服务器出口上网。上游 WiFi（扫描选择/密码/加密方式）、WireGuard 全部参数、
本机热点参数，都在手机浏览器 `http://192.168.4.1/` 里配置。

```
手机/电脑 ──(热点 192.168.4.1, WPA2)── ESP32(APSTA)
                                          │ NAPT
                                          ▼
                                  默认路由 = wg 接口
                                          │
                                          ├── WireGuard UDP(121.40.114.65:53) ── 上游 WiFi ──> 对端
                                          ▼
                                       互联网
```

### 已经过真机验证的行为

| 项 | 证据 |
|---|---|
| 隧道建立 | `{"wg":{"state":"up","handshake":true,"tunnel_ip":"10.66.66.3"}}` |
| 全部流量走隧道 | 客户端 `curl http://ip.3322.net` → `121.40.114.65`（服务器公网 IP） |
| HTTPS / 大流量 | `http_code=200`；2MB 下载 `speed=343555 B/s` |
| 浏览器取时间后才连 WG | 日志 `waiting for time sync` → 推时间后 `wg state -> wait_link/up` |
| NAT 转发 | `"napt":true`，客户端可访问外网 |
| 防泄漏 | WG 断开即 `napt=false`，客户端只会断网，不会走明文 |
""")

    doc.append("""## 1. 重要：四个必须知道的坑（都已修，重编/移植时别丢）

1. **`esp_netif` 的 netif 扩展回调把 `netif->state` 当 `esp_netif_t*`**
   → `esp_wireguard` 建隧道接口时崩溃 `Guru Meditation (LoadProhibited)`。
   修法：`CONFIG_ESP_NETIF_BRIDGE_EN=y`（让 esp_netif 改用 `netif->client_data`）。

2. **表单解析把长 base64 密钥截断**
   URL 编码后 44 字符私钥变 48 字符（`+`→`%2B`、`=`→`%3D`），旧代码先拷进目标字段再解码 → 尾巴被裁。
   修法：`form_get()` 先解码到 512 字节临时缓冲区。

3. **客户端 WiFi 连着但上不了网（MTU/MSS）**
   隧道 MTU 1280，客户端按 1500 宣告 MSS≈1460 → 服务器发 1460 字节的段被丢 → TLS 卡死。
   修法：`components/relay_hooks` 在 lwIP `ip4_input` 钩子里把 SYN 的 MSS 钳到 1240。

4. **MSS 钩子的校验和增量更新必须用主机序**
   第一版把网络序原始值当主机序参与运算，算出的校验和是错的 → lwIP 丢掉所有 SYN，
   表现是「能 ping 通 192.168.4.1，但 80 端口连不上」。见 `csum_replace16()` 的调用方式。

> 另外：板子的 flash 若是克隆/劣质片，可能出现「读正常、写不进低 512KB」，那种板子刷不了（本项目实测踩过一块 ESP32-D0WD-V3）。
""")

    doc.append("""## 2. 编译与烧写

```powershell
# 环境：ESP-IDF v5.3.2 + xtensa-esp-elf-gcc 13.2.0
cd esp32dn4_wg_relay
idf.py set-target esp32s3      # 经典 ESP32 用 esp32
idf.py build
idf.py -p COM5 flash monitor   # S3 的 USB 口
```

| 芯片 | bootloader 偏移 | 建议 flash 参数 |
|---|---|---|
| ESP32-S3（USB-JTAG） | `0x0` | `--flash_mode dio --flash_size 4MB --flash_freq 80m` |
| ESP32 / D0WD（CP210x） | `0x1000` | `--flash_mode dio --flash_size 4MB --flash_freq 40m` |

**本目录 `dist/` 里已给出可直接刷的产物（S3）**：

| 文件 | 用途 |
|---|---|
| `dist/esp32s3_full_4MB.bin` | **合并镜像，从 0x0 一次刷完（推荐）** |
| `dist/app.bin` / `bootloader.bin` / `partition-table.bin` | 需要分开刷时用 |
| `dist/flash.bat` / `dist/flash.ps1` | 一键刷机（默认 COM5） |

```powershell
# 一条命令刷合并镜像
python -m esptool --chip esp32s3 -p COM5 -b 460800 write_flash --flash_mode dio --flash_size 4MB --flash_freq 80m 0x0 esp32s3_full_4MB.bin
```

烧完手机连 **`ESP32-RELAY` / `relay12345`** → 打开 `http://192.168.4.1/`（页面加载即把手机时间推给板子，
之后 WireGuard 才允许握手）。

### 默认参数

| 项 | 默认值 |
|---|---|
| 热点 | `ESP32-RELAY` / `relay12345`，WPA2，信道 6，网关 `192.168.4.1` |
| 隧道地址 | `10.66.66.3 / 255.255.255.255`（服务端 `[Peer] AllowedIPs = 10.66.66.3/32`） |
| Endpoint | 空（页面里填 `host:port`） |
| MTU / Keepalive | 1280 / 25s |
| 下发给客户端的 DNS | 隧道侧 DNS（页面里配，默认 1.1.1.1 / 8.8.8.8） |

### 服务端要配合的两点

```ini
[Peer]
PublicKey  = <ESP32 公钥>
AllowedIPs = 10.66.66.3/32        # 客户端 NAT 后的源地址

# 服务器上还要
sysctl -w net.ipv4.ip_forward=1
iptables -t nat -A POSTROUTING -s 10.66.66.0/24 -o eth0 -j MASQUERADE
```

## 3. HTTP API（用脚本/curl 也能配）

请求体统一 `application/x-www-form-urlencoded`。

| 方法 | 路径 | 参数 / 说明 |
|---|---|---|
| GET | `/api/status` | 状态、时间、WG(含 handshake)、NAT、堆、运行时长 |
| GET | `/api/config` | 读取全部配置 |
| GET | `/api/scan` | 扫描周边 WiFi（阻塞 2~3s） |
| POST | `/api/time` | `epoch_ms`, `tz` → 校时并尝试拉起隧道 |
| POST | `/api/sta` | `ssid`, `password`, `auth`（0=OPEN,3=WPA2,4=WPA/WPA2,6=WPA3,7=WPA2/WPA3） |
| POST | `/api/ap` | `ssid`, `password`, `auth`, `channel`, `hidden` |
| POST | `/api/wg` | `private_key`, `peer_public_key`, `preshared_key`, `endpoint`, `tunnel_ip`, `tunnel_mask`, `mtu`, `keepalive`, `listen_port`, `dns1`, `dns2`, `enabled` |
| POST | `/api/wgctl` | `action=up|down|restart` |
| POST | `/api/probe` | `ip`, `port` → 从隧道发一次 TCP 连接（区分"设备出不去"和"客户端 NAT 不通"） |
| POST | `/api/misc` | `action=reboot|factory` |

## 4. 目录结构

```
esp32dn4_wg_relay/
├─ CMakeLists.txt / partitions.csv / sdkconfig.defaults
├─ build.ps1 / flash.ps1                     # 原工程的编译/烧写脚本
├─ dist/                                     # 已编译产物 + 一键刷机脚本
├─ docs/                                     # 本文件
├─ tools/                                    # 环境探测/串口/诊断/分块烧写脚本
├─ components/
│  ├─ esp_wireguard/                         # trombik/esp_wireguard v0.9.0 (vendored, 第三方)
│  └─ relay_hooks/                           # 本工程新增：MSS 钳制
└─ main/
   ├─ main.c        启动顺序 + 状态机（时间 → 隧道 → NAT）
   ├─ wifi_mgr.c    APSTA / 扫描 / NAPT / DNS 下发
   ├─ wg_mgr.c      WireGuard 生命周期 / 默认路由切换 / 自检探测
   ├─ time_sync.c   浏览器时间 → settimeofday
   ├─ web_server.c  HTTP 服务 + 表单解析
   ├─ config_store.c NVS 持久化
   └─ index.html    单页配置界面（约 25KB，编译时嵌入）
```

> `components/esp_wireguard` 是第三方组件（BSD-3，仓库 https://github.com/trombik/esp_wireguard ，
> 本工程 vendored 的版本 tag ≈ v0.9.0），正文不重复贴它的源码，只贴本工程自己的代码。

---

# 源码

以下内容由脚本直接从工程文件生成，与 `dist/` 里的固件一一对应。
""")

    doc.append("## 目录\n")
    for sec, files in FILES:
        doc.append(f"- **{sec}**")
        for f in files:
            if (ROOT / f).exists():
                doc.append(f"  - `{f}`")
    doc.append("")

    total_lines = 0
    for sec, files in FILES:
        doc.append(f"\n---\n\n# {sec}\n")
        for f in files:
            p = ROOT / f
            if not p.exists():
                doc.append(f"\n### `{f}`\n\n_（文件缺失）_\n")
                continue
            text = p.read_text(encoding="utf-8", errors="replace").replace("\ufeff", "")
            n = text.count("\n") + 1
            total_lines += n
            lang = LANG.get(p.suffix, "")
            f_tick = fence_for(text)
            doc.append(f"\n### `{f}`  ({n} 行)\n\n{f_tick}{lang}\n{text}\n{f_tick}\n")

    doc.append("\n---\n\n*（文档结束，源码合计约 %d 行）*\n" % total_lines)
    return "\n".join(doc)


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    body = emit_header([])
    OUT.write_text(body, encoding="utf-8")
    print("written:", OUT)
    print("size: %.1f KB, lines: %d" % (OUT.stat().st_size / 1024, body.count("\n") + 1))


if __name__ == "__main__":
    main()
