/*
 * relay_hooks.c - MSS 钳制（TCP MSS clamping）
 *
 * 场景：ESP32 AP 客户端 → NAPT → WireGuard(MTU 1280) → 互联网。
 * 客户端按自己 1500 的 MTU 宣告 MSS≈1460，服务器于是发 1460 字节的段，
 * 这些段超过隧道 MTU 被丢弃，表现就是 HTTPS 卡死。
 *
 * 做法：在 ip4_input 钩子里找到客户端发出的 TCP SYN（带 MSS 选项），
 * 把 MSS 改成 (隧道MTU - 40)，并增量修正 TCP 校验和。
 * 服务器收到后就只会发 ≤1240 字节的段，不再触发 MTU 问题。
 */
#include <string.h>
#include <stdint.h>

#include "lwip/pbuf.h"
#include "lwip/netif.h"
#include "lwip/ip.h"
#include "lwip/tcp.h"
#include "lwip/prot/ip4.h"
#include "lwip/prot/tcp.h"

#include "relay_lwip_hooks.h"

/* 与 relay 主程序里的隧道 MTU 保持一致（1280 - 40 字节 IP/TCP 头 = 1240） */
#define RELAY_TUNNEL_MTU      1280
#define RELAY_CLAMP_MSS       (RELAY_TUNNEL_MTU - 40)

/* RFC1624 增量更新 16 位反码校验和 */
static uint16_t csum_replace16(uint16_t old_sum, uint16_t old_word, uint16_t new_word)
{
    uint32_t sum = (uint16_t)~old_sum;
    sum += (uint16_t)~old_word;
    sum += new_word;
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (uint16_t)~sum;
}

int relay_ip4_input_hook(struct pbuf *p, struct netif *inp)
{
    (void)inp;
    if (p == NULL || p->len < sizeof(struct ip_hdr)) return 0;

    struct ip_hdr *iph = (struct ip_hdr *)p->payload;
    if (IPH_V(iph) != 4) return 0;
    if (IPH_PROTO(iph) != IP_PROTO_TCP) return 0;

    uint16_t ip_hl = IPH_HL(iph) * 4u;
    if (ip_hl < sizeof(struct ip_hdr)) return 0;
    if (p->len < ip_hl + sizeof(struct tcp_hdr)) return 0;

    struct tcp_hdr *tcph = (struct tcp_hdr *)((uint8_t *)p->payload + ip_hl);

    /* 只看客户端发出的 SYN（不带 ACK） */
    uint8_t flags = TCPH_FLAGS(tcph);
    if ((flags & TCP_SYN) == 0 || (flags & TCP_ACK) != 0) return 0;
    if (TCPH_HDRLEN(tcph) < 5) return 0;

    uint8_t *opt = (uint8_t *)tcph + sizeof(struct tcp_hdr);
    int opt_len = (int)(TCPH_HDRLEN(tcph) * 4) - (int)sizeof(struct tcp_hdr);
    if (opt_len <= 0) return 0;
    if ((uint8_t *)opt + opt_len > (uint8_t *)p->payload + p->len) return 0;

    int i = 0;
    while (i < opt_len) {
        uint8_t kind = opt[i];
        if (kind == 0) break;                 /* End of option list */
        if (kind == 1) { i++; continue; }     /* NOP */
        if (i + 1 >= opt_len) break;
        uint8_t len = opt[i + 1];
        if (len < 2 || i + len > opt_len) break;

        if (kind == 2 && len == 4) {          /* MSS option */
            /* 按字节读写，避免非对齐 16 位访问 */
            uint8_t *mss_p = opt + i + 2;
            uint16_t mss = (uint16_t)((mss_p[0] << 8) | mss_p[1]);
            if (mss > RELAY_CLAMP_MSS) {
                mss_p[0] = (uint8_t)(RELAY_CLAMP_MSS >> 8);
                mss_p[1] = (uint8_t)(RELAY_CLAMP_MSS & 0xFF);
                /* 增量修正 TCP 校验和：两个 16 位字都用主机序参与运算 */
                uint16_t sum = csum_replace16((uint16_t)ntohs(tcph->chksum),
                                              mss, (uint16_t)RELAY_CLAMP_MSS);
                tcph->chksum = htons(sum);
            }
            return 0;
        }
        i += len;
    }
    return 0;
}
