#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "app_config.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    WG_STATE_OFF = 0,
    WG_STATE_WAIT_TIME,
    WG_STATE_WAIT_LINK,
    WG_STATE_CONNECTING,
    WG_STATE_UP,
    WG_STATE_ERROR,
} wg_state_t;

void wg_mgr_init(void);

/* 启动隧道（必须已同步时间 + STA 已拿到 IP） */
esp_err_t wg_mgr_start(void);
void      wg_mgr_stop(void);

/* 异步版：从 HTTP 处理函数里调用，避免 endpoint 域名解析阻塞 httpd */
esp_err_t wg_mgr_up_async(void);
esp_err_t wg_restart_async(void);

bool        wg_mgr_is_up(void);

/* 穿过隧道的明文吞吐（字节/秒）：supervisor 每秒 tick 一次，状态页读取 */
void        wg_mgr_traffic_tick(void);
void        wg_mgr_traffic_rates(uint32_t *tx_bps, uint32_t *rx_bps);

/* 是否收到对端握手（真正通了） */
bool        wg_mgr_peer_up(void);
wg_state_t  wg_mgr_state(void);
const char *wg_mgr_state_str(void);
const char *wg_mgr_last_error(void);

/* 用户在网页上手动断开后，自动上线逻辑停止推进 */
bool wg_mgr_user_stopped(void);
void wg_mgr_set_user_stopped(bool stopped);

/* 校验配置合法性，返回 ESP_OK 或错误；msg 返回可读原因 */
esp_err_t wg_mgr_validate(const relay_wg_cfg_t *wg, char *msg, size_t msg_len);

/* 编译期是否真的链接到了 wireguard 组件 */
bool wg_mgr_available(void);

/* 自检：从隧道出去连一个 TCP 8000/80 端口，返回 ESP_OK 表示设备自身能出网 */
esp_err_t wg_mgr_probe(const char *ip, int port, int timeout_ms);

/* 隧道接口地址（组件内部网段，如 172.16.0.2），服务端 [Peer] AllowedIPs 需要它 */
void wg_mgr_tunnel_ip(char *buf, size_t n);

#ifdef __cplusplus
}
#endif
