#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    TIME_SRC_NONE = 0,
    TIME_SRC_BROWSER,
    TIME_SRC_SNTP,
} time_src_t;

void time_sync_init(void);

/* 用浏览器/手机时间（毫秒 epoch）设置系统时间 */
esp_err_t time_sync_set_from_browser(int64_t epoch_ms, const char *tz);

/* 是否已同步（WireGuard 上线的前置条件） */
bool time_sync_ready(void);

time_src_t time_sync_source(void);
const char *time_sync_source_str(void);

/* 当前时间字符串 "2026-10-29 22:53:46" */
void time_sync_now_str(char *buf, size_t n);

/* 当前 epoch 秒 */
time_t time_sync_epoch(void);

/* 可选兜底：STA 联网后用 SNTP 取时间（未同步时才启用） */
esp_err_t time_sync_bootstrap_sntp(void);

#ifdef __cplusplus
}
#endif
