#!/usr/bin/env python3
"""一次连接内跑完整写入能力矩阵，给出结论。

用法: python tools/diag2.py COM9 [115200] [等下载模式秒数]
"""
import subprocess
import sys
import time
from pathlib import Path

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM9"
BAUD = sys.argv[2] if len(sys.argv) > 2 else "115200"
TIMEOUT = int(sys.argv[3]) if len(sys.argv) > 3 else 1800
PY = sys.executable

BASE = [PY, "-m", "esptool", "--chip", "esp32", "-p", PORT, "-b", BAUD,
        "--before", "no_reset", "--after", "no_reset"]

PAT = Path("C:/esp/_t4k.bin")
RB = Path("C:/esp/_rb.bin")


def run(args, extra=None):
    r = subprocess.run(BASE + (extra or []) + args, capture_output=True, text=True)
    return r.returncode, ((r.stdout or "") + (r.stderr or ""))


def wait_dl():
    print("等待下载模式（按住 BOOT，拔插 USB）...")
    t0 = time.time()
    n = 0
    while time.time() - t0 < TIMEOUT:
        n += 1
        rc, out = run(["flash_id"])
        if "Chip is ESP32" in out:
            print("connected:", [l.strip() for l in out.splitlines() if "Chip is" in l][0])
            for l in out.splitlines():
                if any(k in l for k in ("Manufacturer", "Device", "Detected flash")):
                    print("  ", l.strip())
            return True
        if n % 15 == 0:
            print("   ... %d 次 (%.0fs)" % (n, time.time() - t0))
        time.sleep(2)
    return False


def try_write(label, addr, extra=None, mode="dout", freq="20m"):
    print("\n--- %s ---" % label)
    rc, out = run(["write_flash", "--flash_mode", mode, "--flash_size", "4MB",
                   "--flash_freq", freq, hex(addr), str(PAT)], extra)
    for l in out.splitlines():
        if any(k in l for k in ("Writing at", "Wrote", "Flash md5", "fatal", "error", "Erasing")):
            print("   ", l.strip()[:120])
    rc2, _ = run(["read_flash", hex(addr), "4096", str(RB)], extra)
    if rc2 == 0 and RB.exists():
        got, want = RB.read_bytes(), PAT.read_bytes()
        if got == want:
            print("   => 写入验证一致 ✔")
            return True
        diff = next((i for i in range(min(len(got), len(want))) if got[i] != want[i]), -1)
        print("   => 回读不一致 ✘  diff@%d got=%s want=%s" %
              (diff, got[diff:diff + 4].hex() if diff >= 0 else "-",
               want[diff:diff + 4].hex() if diff >= 0 else "-"))
        return False
    print("   => 回读失败")
    return False


def main():
    PAT.write_bytes(bytes(range(256)) * 16)
    if not wait_dl():
        print("没等到下载模式")
        return 1

    results = []
    results.append(("stub, DOUT 20MHz", try_write("stub / DOUT / 20MHz", 0x9000)))
    results.append(("stub, DIO 40MHz", try_write("stub / DIO / 40MHz", 0xA000, mode="dio", freq="40m")))
    results.append(("ROM loader", try_write("ROM loader (--no-stub)", 0xB000, extra=["--no-stub"])))

    print("\n==== 结论 ====")
    for name, ok in results:
        print("  %-22s %s" % (name, "写成功 ✔" if ok else "写失败 ✘"))
    if all(ok for _, ok in results):
        print("=> flash 正常，之前是链路/模式问题，可以整片烧写")
    elif any(ok for _, ok in results):
        print("=> 部分模式可写：用能写的那个模式烧（见上）")
    else:
        print("=> 所有模式都写不进：flash 硬件/供电问题，换 USB 线/供电口或换板")
        print("   （读能通、写全失败 + JEDEC ID 读到 0x0b/0x7fff 是供电塌陷或 flash 损坏的典型表现）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
