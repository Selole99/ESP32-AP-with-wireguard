/*
 * time_sync.c - 时间同步
 *
 * 设计：
 *  1) 浏览器（手机/电脑）打开配置页面时，JS 会把 Date.now() 通过 POST /api/time 上送；
 *  2) 本模块用 settimeofday() 写入系统时间，并设置 POSIX TZ；
 *  3) WireGuard 握手依赖时间，所以 wg_mgr_start() 会先检查 time_sync_ready()；
 *  4) 可选兜底：未同步时允许用 SNTP（默认关闭，避免 WG 前出现明文流量）。
 */
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

#include "esp_log.h"
#include "esp_idf_version.h"
#include "esp_sntp.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "time_sync.h"
#include "config_store.h"

static const char *TAG = "time";

static volatile bool     s_ready;
static volatile time_src_t s_src;
static char              s_tz[RELAY_TZ_MAX] = "CST-8";
static bool              s_sntp_started;

void time_sync_init(void)
{
    const relay_cfg_t *c = config_get();
    relay_str_copy(s_tz, sizeof(s_tz), c->time.tz[0] ? c->time.tz : "CST-8");
    setenv("TZ", s_tz, 1);
    tzset();
    s_ready = false;
    s_src   = TIME_SRC_NONE;
    ESP_LOGI(TAG, "init, tz=%s", s_tz);
}

static void apply_tz(const char *tz)
{
    if (tz == NULL || tz[0] == '\0') return;
    relay_str_copy(s_tz, sizeof(s_tz), tz);
    setenv("TZ", s_tz, 1);
    tzset();
}

esp_err_t time_sync_set_from_browser(int64_t epoch_ms, const char *tz)
{
    if (epoch_ms <= 0) return ESP_ERR_INVALID_ARG;

    /* 合理区间检查：2020-01-01 ~ 2050-01-01 */
    int64_t sec = epoch_ms / 1000;
    if (sec < 1577836800LL || sec > 2524608000LL) {
        ESP_LOGW(TAG, "browser epoch out of range: %lld", (long long)sec);
        return ESP_ERR_INVALID_ARG;
    }

    apply_tz(tz);

    struct timeval tv = {
        .tv_sec  = (time_t)sec,
        .tv_usec = (suseconds_t)((epoch_ms % 1000) * 1000),
    };
    if (settimeofday(&tv, NULL) != 0) {
        ESP_LOGE(TAG, "settimeofday failed");
        return ESP_FAIL;
    }

    s_src   = TIME_SRC_BROWSER;
    s_ready = true;

    char buf[32];
    time_sync_now_str(buf, sizeof(buf));
    ESP_LOGI(TAG, "time set from browser: %s (epoch=%lld), tz=%s", buf,
             (long long)sec, s_tz);
    return ESP_OK;
}

bool time_sync_ready(void)   { return s_ready; }
time_src_t time_sync_source(void) { return s_src; }

const char *time_sync_source_str(void)
{
    switch (s_src) {
    case TIME_SRC_BROWSER: return "browser";
    case TIME_SRC_SNTP:    return "sntp";
    default:               return "none";
    }
}

time_t time_sync_epoch(void)
{
    return time(NULL);
}

void time_sync_now_str(char *buf, size_t n)
{
    if (buf == NULL || n == 0) return;
    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    strftime(buf, n, "%Y-%m-%d %H:%M:%S", &tm_now);
}

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 1, 0)
#define RELAY_SNTP_CB esp_sntp_set_time_sync_notification_cb
#else
#define RELAY_SNTP_CB sntp_set_time_sync_notification_cb
#endif

static void sntp_cb(struct timeval *tv)
{
    (void)tv;
    if (!s_ready) {
        s_ready = true;
        s_src   = TIME_SRC_SNTP;
        char buf[32];
        time_sync_now_str(buf, sizeof(buf));
        ESP_LOGI(TAG, "time set from SNTP: %s", buf);
    }
}

esp_err_t time_sync_bootstrap_sntp(void)
{
    if (s_ready) return ESP_OK;
    if (s_sntp_started) return ESP_OK;

    esp_sntp_setoperatingmode(ESP_SNTP_OPMODE_POLL);
    esp_sntp_setservername(0, "ntp.aliyun.com");
    esp_sntp_setservername(1, "pool.ntp.org");
    RELAY_SNTP_CB(sntp_cb);
    esp_sntp_init();
    s_sntp_started = true;
    ESP_LOGW(TAG, "SNTP bootstrap started (this traffic is NOT inside WireGuard)");
    return ESP_OK;
}
