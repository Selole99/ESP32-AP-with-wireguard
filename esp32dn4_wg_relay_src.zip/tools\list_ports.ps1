﻿# 列出电脑上当前可用的串口，用来确认 ESP32 是哪一个（例如 COM9）
#   .\tools\list_ports.ps1

try {
    $ports = [System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object
    if (-not $ports) {
        Write-Host "没有检测到任何串口。检查 USB 线/驱动（CP210x 或 CH340）。" -ForegroundColor Yellow
        exit 1
    }
    Write-Host "可用串口:" -ForegroundColor Cyan
    foreach ($p in $ports) {
        $info = $null
        try {
            $info = Get-CimInstance Win32_SerialPort -Filter "DeviceID='$p'" -ErrorAction Stop
        } catch { }
        if ($info) {
            "{0,-8} {1}" -f $p, $info.Description
        } else {
            "{0,-8} (无描述)" -f $p
        }
    }
    Write-Host ""
    Write-Host "烧写示例: .\flash.ps1 -Port COM9" -ForegroundColor Green
} catch {
    Write-Host "枚举失败: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
