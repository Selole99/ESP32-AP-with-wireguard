﻿# 载入 ESP-IDF 环境（在 build.ps1 / flash.ps1 里 dot-source 本文件）
# 可通过 -IdfPath 或环境变量 IDF_PATH 指定，否则自动探测常见安装位置。

param(
    [string]$IdfPath = $(if ($env:RELAY_IDF_PATH) { $env:RELAY_IDF_PATH } else { $env:IDF_PATH })
)

$ErrorActionPreference = "Continue"

function Find-IdfExport {
    param([string]$Hint)
    $cands = @()
    if ($Hint) { $cands += $Hint }
    if ($env:IDF_PATH) { $cands += $env:IDF_PATH }
    $cands += @(
        "C:\Espressif\frameworks\esp-idf-v5.4.1",
        "C:\Espressif\frameworks\esp-idf-v5.3.2",
        "C:\Espressif\frameworks\esp-idf-v5.2.3",
        "C:\Espressif\frameworks\esp-idf-v5.1.4",
        "C:\Espressif\frameworks\esp-idf-v5.0.7",
        "C:\esp\esp-idf",
        "$env:USERPROFILE\esp\esp-idf",
        "$env:USERPROFILE\esp-idf"
    )
    # 再扫一遍 C:\Espressif\frameworks
    if (Test-Path "C:\Espressif\frameworks") {
        $cands += (Get-ChildItem "C:\Espressif\frameworks" -Directory |
                   Where-Object { $_.Name -like "esp-idf*" } |
                   Sort-Object Name -Descending |
                   ForEach-Object { $_.FullName })
    }
    foreach ($c in $cands) {
        if ($c -and (Test-Path (Join-Path $c "export.ps1"))) { return (Join-Path $c "export.ps1") }
    }
    return $null
}

if (Get-Command idf.py -ErrorAction SilentlyContinue) {
    Write-Host "[idf] 已存在 idf.py，跳过环境载入" -ForegroundColor DarkGray
    return
}

$export = Find-IdfExport -Hint $IdfPath
if (-not $export) {
    Write-Host "[idf] 找不到 ESP-IDF (export.ps1)。请先安装 ESP-IDF，或用 -IdfPath 指定：" -ForegroundColor Yellow
    Write-Host "      .\flash.ps1 -Port COM9 -IdfPath C:\Espressif\frameworks\esp-idf-v5.x" -ForegroundColor Yellow
    throw "ESP-IDF not found"
}

Write-Host "[idf] 载入 $export" -ForegroundColor DarkGray
& $export | Out-Null
