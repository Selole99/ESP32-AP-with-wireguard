﻿# 依赖拉取 / 离线兜底
# 1) 正常情况：编译时 ESP-IDF 组件管理器会从注册表拉取 trombik/esp_wireguard
# 2) 网络不通时：用本脚本把组件克隆到 components/ 目录，并注释掉 idf_component.yml 的依赖

param(
    [string]$Ref = "master",
    [switch]$Vendor
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot

if (-not $Vendor) {
    Write-Host "拉取托管依赖（需要能访问 components.espressif.com）..." -ForegroundColor Cyan
    Push-Location $root
    try {
        . (Join-Path $root "tools\idf.ps1")
        idf.py reconfigure
    } finally { Pop-Location }
    exit 0
}

# ---- 离线：vendored 到 components/ ----
$dst = Join-Path $root "components\esp_wireguard"
if (Test-Path $dst) {
    Write-Host "已存在 $dst，先删除再重来" -ForegroundColor Yellow
    Remove-Item -Recurse -Force $dst
}
New-Item -ItemType Directory -Force -Path (Join-Path $root "components") | Out-Null

Write-Host "git clone trombik/esp_wireguard -> components/esp_wireguard" -ForegroundColor Cyan
git clone --depth 1 --branch $Ref https://github.com/trombik/esp_wireguard.git $dst
if ($LASTEXITCODE -ne 0) { throw "clone failed" }

$yml = Join-Path $root "main\idf_component.yml"
if (Test-Path $yml) {
    Copy-Item $yml "$yml.bak" -Force
    @"
dependencies:
  idf:
    version: ">=5.0"
# 已改为 components/esp_wireguard 本地组件（离线模式），如需联网拉取请恢复 idf_component.yml.bak
"@ | Set-Content -Path $yml -Encoding UTF8
    Write-Host "已改写 $yml（备份: idf_component.yml.bak）" -ForegroundColor Yellow
}

$cmake = Join-Path $root "main\CMakeLists.txt"
$txt = Get-Content $cmake -Raw
if ($txt -notmatch "esp_wireguard") {
    Write-Host "提示：如编译报 wireguard.h 找不到，请把 esp_wireguard 加入 main/CMakeLists.txt 的 REQUIRES" -ForegroundColor Yellow
}

Write-Host "完成。现在执行 .\build.ps1" -ForegroundColor Green
