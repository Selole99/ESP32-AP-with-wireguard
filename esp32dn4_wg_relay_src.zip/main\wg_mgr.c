/*
 * wg_mgr.c - WireGuard 隧道管理（适配 trombik/esp_wireguard v0.9 API）
 *
 * 关键点
 *  1) 时间前置：WireGuard 握手用 TAI64N 时间戳，时间不对会被对端丢弃，
 *     所以必须 time_sync_ready() 之后才 connect。
 *  2) 全网流量入隧道：连上后 esp_wireguard_set_default() 把 lwIP 默认 netif
 *     切到 wg 接口，于是 ESP32 自身流量 + NAPT 转发的客户端流量都进隧道；
 *     断开时库自己恢复原默认 netif，上层同时关 NAPT，避免明文泄漏。
 *  3) allowed_ip / allowed_ip_mask 在本库里是「隧道接口自身地址」，
 *     也是 NAT 之后客户端流量的源地址，必须是真实地址（如 10.66.66.2/24），
 *     服务端 [Peer] AllowedIPs 要写 10.66.66.2/32。
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "sdkconfig.h"
#include "esp_log.h"
#include "lwip/netif.h"
#include "lwip/sockets.h"
#include "lwip/ip_addr.h"

#include "esp_netif.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#include "wg_mgr.h"
#include "config_store.h"
#include "wifi_mgr.h"
#include "time_sync.h"

#if defined(__has_include)
#  if __has_include("esp_wireguard.h")
#    include "esp_wireguard.h"
#    define RELAY_HAVE_WIREGUARD 1
#  elif __has_include("wireguard.h")
#    include "wireguard.h"
#    define RELAY_HAVE_WIREGUARD 1
#  else
#    define RELAY_HAVE_WIREGUARD 0
#  endif
#else
#  define RELAY_HAVE_WIREGUARD 0
#endif

static const char *TAG = "wg";

static volatile wg_state_t s_state = WG_STATE_OFF;
static char       s_err[96] = "not started";
static bool       s_user_stopped;

/* start/stop 会被 supervisor、httpd、重启任务并发调用，必须串行化 */
static SemaphoreHandle_t s_mtx;

static esp_err_t wg_mgr_start_impl(void);
static void      wg_mgr_stop_impl(void);

#if RELAY_HAVE_WIREGUARD
extern uint32_t wireguardif_tx_bytes(void);
extern uint32_t wireguardif_rx_bytes(void);
#endif

/* 隧道吞吐采样（字节/秒） */
static uint32_t s_tx_bps;
static uint32_t s_rx_bps;
static uint32_t s_tx_last;
static uint32_t s_rx_last;
static int64_t  s_traffic_us;

#if RELAY_HAVE_WIREGUARD
static wireguard_config_t s_raw_cfg;
static wireguard_ctx_t    s_ctx;
static bool               s_inited;

/* 组件内部会 strdup 一份，这里仍保留生命周期稳定的缓冲区 */
static char s_buf_priv[64];
static char s_buf_pub[64];
static char s_buf_psk[64];
static char s_buf_ep[96];
static char s_buf_addr[24];
static char s_buf_mask[24];
#endif

static void set_state(wg_state_t st, const char *err)
{
    s_state = st;
    if (err) snprintf(s_err, sizeof(s_err), "%s", err);
}

void wg_mgr_init(void)
{
    s_state        = WG_STATE_OFF;
    s_user_stopped = false;
    snprintf(s_err, sizeof(s_err), "not started");
    if (s_mtx == NULL) s_mtx = xSemaphoreCreateMutex();
    ESP_LOGI(TAG, "wireguard component: %s",
             RELAY_HAVE_WIREGUARD ? "available" : "MISSING (stub build)");
}

bool        wg_mgr_is_up(void)      { return s_state == WG_STATE_UP; }
wg_state_t  wg_mgr_state(void)      { return s_state; }
bool        wg_mgr_user_stopped(void) { return s_user_stopped; }
void        wg_mgr_set_user_stopped(bool s) { s_user_stopped = s; }
const char *wg_mgr_last_error(void) { return s_err; }
bool        wg_mgr_available(void)  { return RELAY_HAVE_WIREGUARD ? true : false; }

void wg_mgr_traffic_tick(void)
{
#if RELAY_HAVE_WIREGUARD
    uint32_t tx = wireguardif_tx_bytes();
    uint32_t rx = wireguardif_rx_bytes();
    int64_t  now = esp_timer_get_time();

    if (s_traffic_us == 0) {
        s_traffic_us = now;
        s_tx_last = tx;
        s_rx_last = rx;
        return;
    }
    int64_t dt = now - s_traffic_us;
    if (dt < 1000000) return;

    s_tx_bps = (uint32_t)((uint64_t)(uint32_t)(tx - s_tx_last) * 1000000ULL / (uint64_t)dt);
    s_rx_bps = (uint32_t)((uint64_t)(uint32_t)(rx - s_rx_last) * 1000000ULL / (uint64_t)dt);
    s_tx_last = tx;
    s_rx_last = rx;
    s_traffic_us = now;
#endif
}

void wg_mgr_traffic_rates(uint32_t *tx_bps, uint32_t *rx_bps)
{
    if (tx_bps) *tx_bps = s_tx_bps;
    if (rx_bps) *rx_bps = s_rx_bps;
}

/* 是否有真实握手（比"接口已建"更能说明隧道通了） */
bool wg_mgr_peer_up(void)
{
#if RELAY_HAVE_WIREGUARD
    if (!s_inited || s_ctx.netif == NULL) return false;
    return esp_wireguardif_peer_is_up(&s_ctx) == ESP_OK;
#else
    return false;
#endif
}

void wg_mgr_tunnel_ip(char *buf, size_t n)
{
    if (buf == NULL || n == 0) return;
    relay_str_copy(buf, n, "-");
#if RELAY_HAVE_WIREGUARD
    if (s_inited && s_ctx.netif != NULL) {
        ipaddr_ntoa_r(&s_ctx.netif->ip_addr, buf, (int)n);
    }
#endif
}

const char *wg_mgr_state_str(void)
{
    switch (s_state) {
    case WG_STATE_WAIT_TIME:  return "wait_time";
    case WG_STATE_WAIT_LINK:  return "wait_link";
    case WG_STATE_CONNECTING: return "connecting";
    case WG_STATE_UP:         return "up";
    case WG_STATE_ERROR:      return "error";
    default:                  return "off";
    }
}

/* ------------------------------------------------------------------ */
/* 配置校验                                                            */
/* ------------------------------------------------------------------ */
static int b64_decoded_len(const char *s)
{
    size_t n = strlen(s);
    if (n == 0 || n % 4 != 0) return -1;
    int pad = 0;
    if (s[n - 1] == '=') pad++;
    if (n > 1 && s[n - 2] == '=') pad++;
    return (int)(n / 4 * 3) - pad;
}

esp_err_t wg_mgr_validate(const relay_wg_cfg_t *wg, char *msg, size_t msg_len)
{
#define FAIL(...) do { if (msg) snprintf(msg, msg_len, __VA_ARGS__); return ESP_ERR_INVALID_ARG; } while (0)
    if (wg == NULL) FAIL("config null");

    if (b64_decoded_len(wg->priv) != 32)
        FAIL("私钥必须是 44 字符 base64（32 字节）");
    if (b64_decoded_len(wg->peer_pub) != 32)
        FAIL("对端公钥必须是 44 字符 base64（32 字节）");
    if (wg->psk[0] && b64_decoded_len(wg->psk) != 32)
        FAIL("预共享密钥必须是 44 字符 base64（32 字节）");

    if (wg->endpoint[0] == '\0') FAIL("缺少 Endpoint");
    const char *colon = strrchr(wg->endpoint, ':');
    if (colon == NULL || colon == wg->endpoint)
        FAIL("Endpoint 格式应为 host:port");
    int port = atoi(colon + 1);
    if (port <= 0 || port > 65535) FAIL("Endpoint 端口非法");

    ip_addr_t a;
    if (!ipaddr_aton(wg->tunnel_ip, &a)) FAIL("隧道地址非法");
    if (ip_addr_isany(&a)) FAIL("隧道地址不能是 0.0.0.0（NAT 源地址需要真实 IP，如 10.66.66.2）");
    if (!ipaddr_aton(wg->tunnel_mask, &a)) FAIL("隧道掩码非法");

    /* 内层 MTU 超过 1420 时，加密后的外层包（+60 字节）会超过 1500 被二次分片 */
    if (wg->mtu < 576 || wg->mtu > 1420) FAIL("MTU 应在 576~1420（推荐 1280）");
    if (msg && msg_len) snprintf(msg, msg_len, "ok");
    return ESP_OK;
#undef FAIL
}

#if RELAY_HAVE_WIREGUARD
/* "host:port" -> host, port */
static bool split_endpoint(const char *in, char *host, size_t hn, int *port)
{
    const char *colon = strrchr(in, ':');
    if (colon == NULL || colon == in) return false;
    size_t hl = (size_t)(colon - in);
    if (hl >= hn) return false;
    memcpy(host, in, hl);
    host[hl] = '\0';
    int p = atoi(colon + 1);
    if (p <= 0 || p > 65535) return false;
    *port = p;
    return true;
}
#endif

/* ------------------------------------------------------------------ */
/* 启停                                                                */
/* ------------------------------------------------------------------ */
static esp_err_t wg_mgr_start_impl(void)
{
    const relay_cfg_t *c = config_get();

    if (!c->wg.enabled) {
        set_state(WG_STATE_OFF, "wireguard disabled in config");
        return ESP_ERR_INVALID_STATE;
    }
    if (!time_sync_ready()) {
        set_state(WG_STATE_WAIT_TIME, "waiting for browser time sync");
        return ESP_ERR_INVALID_STATE;
    }
    if (!wifi_mgr_sta_has_ip()) {
        set_state(WG_STATE_WAIT_LINK, "waiting for upstream wifi ip");
        return ESP_ERR_INVALID_STATE;
    }

    char msg[96];
    if (wg_mgr_validate(&c->wg, msg, sizeof(msg)) != ESP_OK) {
        set_state(WG_STATE_ERROR, msg);
        ESP_LOGE(TAG, "config invalid: %s", msg);
        return ESP_ERR_INVALID_ARG;
    }

#if !RELAY_HAVE_WIREGUARD
    set_state(WG_STATE_ERROR, "wireguard component missing");
    return ESP_ERR_NOT_SUPPORTED;
#else
    if (s_state == WG_STATE_UP) return ESP_OK;

    set_state(WG_STATE_CONNECTING, "connecting");
    ESP_LOGI(TAG, "starting tunnel -> %s (tunnel addr %s/%s)",
             c->wg.endpoint, c->wg.tunnel_ip, c->wg.tunnel_mask);

    memset(&s_raw_cfg, 0, sizeof(s_raw_cfg));

    relay_str_copy(s_buf_priv, sizeof(s_buf_priv), c->wg.priv);
    relay_str_copy(s_buf_pub, sizeof(s_buf_pub), c->wg.peer_pub);
    relay_str_copy(s_buf_psk, sizeof(s_buf_psk),
                   c->wg.psk[0] ? c->wg.psk
                                : "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
    relay_str_copy(s_buf_addr, sizeof(s_buf_addr), c->wg.tunnel_ip);
    relay_str_copy(s_buf_mask, sizeof(s_buf_mask), c->wg.tunnel_mask);

    int port = 51820;
    if (!split_endpoint(c->wg.endpoint, s_buf_ep, sizeof(s_buf_ep), &port)) {
        set_state(WG_STATE_ERROR, "endpoint parse failed");
        return ESP_FAIL;
    }

    s_raw_cfg.private_key         = s_buf_priv;
    s_raw_cfg.public_key          = s_buf_pub;
    s_raw_cfg.preshared_key       = s_buf_psk;
    s_raw_cfg.endpoint            = s_buf_ep;
    s_raw_cfg.port                = port;
    s_raw_cfg.listen_port         = c->wg.listen_port ? c->wg.listen_port : 51820;
    s_raw_cfg.allowed_ip          = s_buf_addr;
    s_raw_cfg.allowed_ip_mask     = s_buf_mask;
    s_raw_cfg.persistent_keepalive = c->wg.keepalive;

    /* init 只需一次（内部会初始化 mbedtls 熵源），之后仅刷新 config 指针 */
    esp_err_t err;
    if (!s_inited) {
        err = esp_wireguard_init(&s_raw_cfg, &s_ctx);
        if (err != ESP_OK) {
            char m[64];
            snprintf(m, sizeof(m), "esp_wireguard_init: %s", esp_err_to_name(err));
            set_state(WG_STATE_ERROR, m);
            ESP_LOGE(TAG, "%s", m);
            return err;
        }
        s_inited = true;
    } else {
        s_ctx.config = &s_raw_cfg;
        if (s_ctx.netif != NULL) {
            /* 上一轮没干净断开，先拆掉 */
            esp_wireguard_disconnect(&s_ctx);
        }
    }

    err = esp_wireguard_connect(&s_ctx);
    if (err != ESP_OK) {
        char m[64];
        snprintf(m, sizeof(m), "connect failed: %s (检查 Endpoint/公钥/时间)",
                 esp_err_to_name(err));
        set_state(WG_STATE_ERROR, m);
        ESP_LOGE(TAG, "%s", m);
        return err;
    }

    /* 默认路由切到隧道：ESP32 自身 + NAT 转发的客户端流量全部入隧道 */
    err = esp_wireguard_set_default(&s_ctx);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_wireguard_set_default: %s", esp_err_to_name(err));
    }
    if (s_ctx.netif != NULL && c->wg.mtu) {
        s_ctx.netif->mtu = c->wg.mtu;
    }

    set_state(WG_STATE_UP, "up");
    ESP_LOGI(TAG, "tunnel up: default route -> wg netif, all traffic goes through WireGuard");
    ESP_LOGI(TAG, "服务端 [Peer] AllowedIPs 需包含 %s/32，并开启 ip_forward + MASQUERADE",
             c->wg.tunnel_ip);
    return ESP_OK;
#endif
}

esp_err_t wg_mgr_start(void)
{
    if (s_mtx == NULL) return wg_mgr_start_impl();
    xSemaphoreTake(s_mtx, portMAX_DELAY);
    esp_err_t err = wg_mgr_start_impl();
    xSemaphoreGive(s_mtx);
    return err;
}
void wg_mgr_stop(void)
{
    if (s_mtx) xSemaphoreTake(s_mtx, portMAX_DELAY);
    wg_mgr_stop_impl();
    if (s_mtx) xSemaphoreGive(s_mtx);
}

static void wg_mgr_stop_impl(void)
{
#if RELAY_HAVE_WIREGUARD
    if (s_inited && s_ctx.netif != NULL) {
        /* 库内部会 netif_remove + 恢复 netif_default */
        esp_err_t err = esp_wireguard_disconnect(&s_ctx);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "disconnect: %s", esp_err_to_name(err));
        }
    }
    s_ctx.netif = NULL;
#endif
    if (s_state == WG_STATE_UP || s_state == WG_STATE_CONNECTING ||
        s_state == WG_STATE_ERROR) {
        set_state(WG_STATE_OFF, "stopped");
    } else {
        s_state = WG_STATE_OFF;
    }
    ESP_LOGI(TAG, "tunnel stopped");
}

/* ------------------------------------------------------------------ */
/* 异步封装（HTTP 线程不能被握手/解析阻塞）                            */
/* ------------------------------------------------------------------ */
static void wg_start_task(void *arg)
{
    (void)arg;
    wg_mgr_start();
    vTaskDelete(NULL);
}

static void wg_restart_task(void *arg)
{
    (void)arg;
    wg_mgr_stop();
    wifi_mgr_napt_set(false);
    /* 不在本任务里再 start：supervisor 每秒会按状态自动拉起，
     * 两边同时 start 会重复 netif_add / add_peer，重启反而不稳定。 */
    vTaskDelete(NULL);
}

esp_err_t wg_mgr_up_async(void)
{
    if (!config_get()->wg.enabled) return ESP_ERR_INVALID_STATE;
    if (xTaskCreatePinnedToCore(wg_start_task, "wg_start", 6144, NULL, 5, NULL, 1) != pdPASS)
        return ESP_ERR_NO_MEM;
    return ESP_OK;
}

esp_err_t wg_restart_async(void)
{
    if (xTaskCreatePinnedToCore(wg_restart_task, "wg_restart", 6144, NULL, 5, NULL, 1) != pdPASS)
        return ESP_ERR_NO_MEM;
    return ESP_OK;
}


/* ------------------------------------------------------------------ */
/* 自检：从隧道发一次 TCP 连接（用来区分"设备出不去"和"客户端 NAT 不通"） */
/* ------------------------------------------------------------------ */
esp_err_t wg_mgr_probe(const char *ip, int port, int timeout_ms)
{
    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port   = htons((uint16_t)port);
    if (inet_pton(AF_INET, ip, &sa.sin_addr) != 1) {
        /* lwIP 可能没有 inet_pton，退回 aton */
        uint32_t a = 0;
        if (!esp_ip4addr_aton(ip)) return ESP_ERR_INVALID_ARG;
        a = esp_ip4addr_aton(ip);
        sa.sin_addr.s_addr = a;
    }

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return ESP_FAIL;

    struct timeval tv = { .tv_sec = timeout_ms / 1000 }; /* 简易超时 */
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);

    int r = connect(s, (struct sockaddr *)&sa, sizeof(sa));
    if (r == 0) { close(s); return ESP_OK; }
    if (errno != EINPROGRESS) { close(s); return ESP_FAIL; }

    fd_set wfds;
    FD_ZERO(&wfds);
    FD_SET(s, &wfds);
    struct timeval to = { .tv_sec = timeout_ms / 1000, .tv_usec = (timeout_ms % 1000) * 1000 };
    r = select(s + 1, NULL, &wfds, NULL, &to);
    if (r <= 0) { close(s); return ESP_ERR_TIMEOUT; }

    int err = 0;
    socklen_t len = sizeof(err);
    getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &len);
    close(s);
    return (err == 0) ? ESP_OK : ESP_FAIL;
}
