﻿# 编译固件
#   .\build.ps1                       # 默认配置编译
#   .\build.ps1 -Clean                # 全清后重编
#   .\build.ps1 -IdfPath C:\Espressif\frameworks\esp-idf-v5.3.2

param(
    [string]$IdfPath = "",
    [switch]$Clean,
    [switch]$Menuconfig
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$env:MSYSTEM = ""

if ($IdfPath) { $env:RELAY_IDF_PATH = $IdfPath }
. (Join-Path $root "tools\idf.ps1")

Push-Location $root
try {
    if ($Clean -and (Test-Path "build")) { Remove-Item -Recurse -Force "build" }
    if (-not (Test-Path "sdkconfig")) {
        Write-Host "[build] set-target esp32" -ForegroundColor Cyan
        idf.py set-target esp32
    }
    if ($Menuconfig) { idf.py menuconfig }
    idf.py build
    if ($LASTEXITCODE -ne 0) { throw "build failed ($LASTEXITCODE)" }

    Write-Host ""
    Write-Host "=== 产物 ===" -ForegroundColor Green
    Get-ChildItem "build\*.bin" | ForEach-Object {
        "{0,-42} {1,10:N0} bytes" -f $_.Name, $_.Length
    }
    Write-Host ""
    Write-Host "下一步: .\flash.ps1 -Port COM9" -ForegroundColor Green
}
finally {
    Pop-Location
}
