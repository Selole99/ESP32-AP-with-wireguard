/*
 * wifi_mgr.c - APSTA 模式、扫描、NAPT 转发
 *
 * 拓扑：
 *   手机 ──(AP, 192.168.4.1)── ESP32 ──(STA)── 上游 WiFi ──> 互联网
 *                                   └──(默认路由=WireGuard netif)──> 对端
 *
 * 防泄漏：
 *   NAPT 只在 WireGuard 已连接（默认路由已切到 wg netif）时才打开；
 *   WG 断开立刻关闭 NAPT，客户端只会"上不了网"，不会走明文出口。
 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "sdkconfig.h"
#include "esp_log.h"
#include "esp_idf_version.h"
#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_timer.h"
#include "esp_mac.h"
#include "lwip/inet.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "wifi_mgr.h"
#include "config_store.h"

static const char *TAG = "wifi";

static esp_netif_t *s_ap_netif;
static esp_netif_t *s_sta_netif;

static volatile bool s_sta_conn;
static volatile bool s_sta_ip;
static volatile int  s_ip_gen;
static volatile int  s_ap_clients;
static volatile bool s_napt;
static bool          s_started;

static esp_timer_handle_t s_retry_timer;

/* ------------------------------------------------------------------ */
/* 辅助                                                                */
/* ------------------------------------------------------------------ */
static wifi_auth_mode_t to_idf_auth(uint8_t a)
{
    /* relay_auth_t 数值与 wifi_auth_mode_t 一致 */
    if (a > RELAY_AUTH_WPA2_WPA3_PSK) return WIFI_AUTH_WPA2_PSK;
    return (wifi_auth_mode_t)a;
}

static void retry_timer_cb(void *arg)
{
    (void)arg;
    const relay_cfg_t *c = config_get();
    if (c->sta.ssid[0] == '\0') return;
    if (s_sta_ip) return;
    esp_err_t err = esp_wifi_connect();
    ESP_LOGD(TAG, "reconnect -> %s", esp_err_to_name(err));
}

static void schedule_retry(void)
{
    if (s_retry_timer) {
        esp_timer_stop(s_retry_timer);
        esp_timer_start_once(s_retry_timer, 2 * 1000 * 1000ULL);
    }
}

/* ------------------------------------------------------------------ */
/* 事件处理                                                            */
/* ------------------------------------------------------------------ */
/*
 * STA 连上上游后，把 AP 信道同步成上游所在信道。
 * APSTA 共用一套射频，两者同信道是硬性要求；配置里的 AP 信道只是初始值，
 * 上游信道和它不一致时显式对齐，避免信标仍宣告旧信道导致客户端漫游异常。
 */
static void sync_ap_channel_to_sta(void)
{
    wifi_ap_record_t ap;
    if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return;

    wifi_config_t wc;
    if (esp_wifi_get_config(WIFI_IF_AP, &wc) != ESP_OK) return;
    if (wc.ap.channel == ap.primary) return;   /* 已一致 */

    uint8_t old = wc.ap.channel;
    wc.ap.channel = ap.primary;
    esp_err_t err = esp_wifi_set_config(WIFI_IF_AP, &wc);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "AP channel synced to upstream: %d -> %d", old, ap.primary);
    } else {
        ESP_LOGW(TAG, "AP channel sync failed: %s", esp_err_to_name(err));
    }
}

static void wifi_event_handler(void *arg, esp_event_base_t base,
                               int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT) {
        switch (id) {
        case WIFI_EVENT_STA_START: {
            const relay_cfg_t *c = config_get();
            if (c->sta.ssid[0]) esp_wifi_connect();
            break;
        }
        case WIFI_EVENT_STA_DISCONNECTED: {
            wifi_event_sta_disconnected_t *e = (wifi_event_sta_disconnected_t *)data;
            s_sta_conn = false;
            s_sta_ip   = false;
            ESP_LOGW(TAG, "STA disconnected, reason=%d", e ? e->reason : -1);
            if (e && e->reason == WIFI_REASON_ASSOC_LEAVE) {
                /* 主动断开（配置变更），不重连 */
                break;
            }
            const relay_cfg_t *c = config_get();
            if (c->sta.ssid[0]) schedule_retry();
            break;
        }
        case WIFI_EVENT_STA_CONNECTED:
            s_sta_conn = true;
            ESP_LOGI(TAG, "STA connected to '%s'", config_get()->sta.ssid);
            sync_ap_channel_to_sta();
            break;
        case WIFI_EVENT_AP_STACONNECTED:
            s_ap_clients++;
            ESP_LOGI(TAG, "client joined, total=%d", s_ap_clients);
            break;
        case WIFI_EVENT_AP_STADISCONNECTED:
            if (s_ap_clients > 0) s_ap_clients--;
            ESP_LOGI(TAG, "client left, total=%d", s_ap_clients);
            break;
        default:
            break;
        }
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        s_sta_ip = true;
        s_ip_gen++;
        ESP_LOGI(TAG, "got ip " IPSTR ", gw " IPSTR ", gen=%d",
                 IP2STR(&e->ip_info.ip), IP2STR(&e->ip_info.gw), s_ip_gen);
    } else if (base == IP_EVENT && id == IP_EVENT_STA_LOST_IP) {
        s_sta_ip = false;
        ESP_LOGW(TAG, "lost ip");
    }
}

/* ------------------------------------------------------------------ */
/* 配置应用                                                            */
/* ------------------------------------------------------------------ */
esp_err_t wifi_mgr_apply_sta(const relay_sta_cfg_t *sta)
{
    wifi_config_t wc;
    memset(&wc, 0, sizeof(wc));

    size_t n = strlen(sta->ssid);
    if (n > sizeof(wc.sta.ssid)) n = sizeof(wc.sta.ssid);
    memcpy(wc.sta.ssid, sta->ssid, n);

    size_t pn = strlen(sta->pass);
    if (pn > sizeof(wc.sta.password)) pn = sizeof(wc.sta.password);
    memcpy(wc.sta.password, sta->pass, pn);

    /* 阈值放宽到 OPEN，避免用户选错认证方式后连不上 */
    wc.sta.threshold.authmode = WIFI_AUTH_OPEN;
    wc.sta.pmf_cfg.capable    = true;
    wc.sta.pmf_cfg.required   = false;
    wc.sta.sort_method        = WIFI_CONNECT_AP_BY_SIGNAL;

    esp_err_t err = esp_wifi_set_config(WIFI_IF_STA, &wc);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "set STA config failed: %s", esp_err_to_name(err));
        return err;
    }
    ESP_LOGI(TAG, "STA config applied: ssid='%s' auth=%d", sta->ssid, sta->auth);
    return ESP_OK;
}

esp_err_t wifi_mgr_apply_ap(const relay_ap_cfg_t *ap)
{
    wifi_config_t wc;
    memset(&wc, 0, sizeof(wc));

    size_t n = strlen(ap->ssid);
    if (n == 0 || n > sizeof(wc.ap.ssid)) return ESP_ERR_INVALID_ARG;
    memcpy(wc.ap.ssid, ap->ssid, n);
    wc.ap.ssid_len = n;

    size_t pn = strlen(ap->pass);
    if (pn > sizeof(wc.ap.password)) pn = sizeof(wc.ap.password);
    memcpy(wc.ap.password, ap->pass, pn);

    wc.ap.authmode      = to_idf_auth(ap->auth);
    wc.ap.channel       = ap->channel ? ap->channel : RELAY_AP_DEF_CHAN;
    wc.ap.max_connection = ap->max_conn ? ap->max_conn : 8;
    wc.ap.ssid_hidden   = ap->hidden ? 1 : 0;
    wc.ap.beacon_interval = 100;
    wc.ap.dtim_period      = 1;   /* 省电客户端每个信标都能取包，避免 DTIM 间隔拖慢下载 */
    wc.ap.pmf_cfg.capable  = true;
    wc.ap.pmf_cfg.required = false;

    /* 开放/手机热点场景密码必须为空 */
    if (wc.ap.authmode == WIFI_AUTH_OPEN || wc.ap.authmode == WIFI_AUTH_WEP) {
        memset(wc.ap.password, 0, sizeof(wc.ap.password));
        if (wc.ap.authmode == WIFI_AUTH_WEP) wc.ap.authmode = WIFI_AUTH_OPEN;
    } else if (pn < 8) {
        ESP_LOGE(TAG, "AP password too short (%u), need >=8", (unsigned)pn);
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t err = esp_wifi_set_config(WIFI_IF_AP, &wc);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "set AP config failed: %s", esp_err_to_name(err));
        return err;
    }
    ESP_LOGI(TAG, "AP config applied: ssid='%s' auth=%d ch=%d",
             ap->ssid, ap->auth, wc.ap.channel);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* 初始化                                                              */
/* ------------------------------------------------------------------ */
void wifi_mgr_init(void)
{
    const relay_cfg_t *c = config_get();

    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    s_ap_netif  = esp_netif_create_default_wifi_ap();
    s_sta_netif = esp_netif_create_default_wifi_sta();
    if (s_ap_netif == NULL || s_sta_netif == NULL) {
        ESP_LOGE(TAG, "netif create failed");
        abort();
    }

    wifi_init_config_t ic = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&ic));

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                        wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, ESP_EVENT_ANY_ID,
                                                        wifi_event_handler, NULL, NULL));

    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));

    wifi_mgr_apply_ap(&c->ap);
    wifi_mgr_apply_sta(&c->sta);

    const esp_timer_create_args_t targs = {
        .callback = retry_timer_cb,
        .name     = "wifi_retry",
    };
    esp_timer_create(&targs, &s_retry_timer);

    ESP_ERROR_CHECK(esp_wifi_start());
    esp_wifi_set_bandwidth(WIFI_IF_AP, WIFI_BW_HT20);
    esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT20);
    esp_wifi_set_ps(WIFI_PS_NONE);   /* 关闭省电，降低转发延迟 */

    /* 想关掉 11b 速率防止客户端退到 1Mbps，但 ESP32 的 2.4G 协议位图必须含 11b
     * （只支持 b / bg / bgn），esp_wifi_set_protocol 会返回 INVALID_ARG，只能保持默认 bgn。 */

    s_started = true;
    ESP_LOGI(TAG, "started: AP '%s' / STA '%s'", c->ap.ssid,
             c->sta.ssid[0] ? c->sta.ssid : "<unset>");
}

/* ------------------------------------------------------------------ */
/* 状态查询                                                            */
/* ------------------------------------------------------------------ */
bool wifi_mgr_sta_connected(void) { return s_sta_conn; }
bool wifi_mgr_sta_has_ip(void)    { return s_sta_ip; }
int  wifi_mgr_ip_generation(void) { return s_ip_gen; }

int8_t wifi_mgr_sta_rssi(void)
{
    wifi_ap_record_t ap;
    if (esp_wifi_sta_get_ap_info(&ap) == ESP_OK) return ap.rssi;
    return -127;
}

/* 热点侧客户端的信号强度（取最强的一个），没有客户端返回 -127 */
int8_t wifi_mgr_ap_client_rssi(void)
{
    wifi_sta_list_t list;
    memset(&list, 0, sizeof(list));
    if (esp_wifi_ap_get_sta_list(&list) != ESP_OK || list.num <= 0) return -127;
    int8_t best = -127;
    for (int i = 0; i < list.num; ++i) {
        if (list.sta[i].rssi > best) best = list.sta[i].rssi;
    }
    return best;
}

/* 上游无线链路信息：协议(b/g/n)、当前信道、带宽(MHz) */
esp_err_t wifi_mgr_sta_radio(char *phy, size_t n, uint8_t *ch, uint8_t *bw)
{
    wifi_ap_record_t ap;
    if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return ESP_ERR_INVALID_STATE;

    if (phy && n) {
        snprintf(phy, n, "%s%s%s",
                 ap.phy_11b ? "b" : "", ap.phy_11g ? "g" : "", ap.phy_11n ? "n" : "");
    }

    uint8_t primary = 0;
    wifi_second_chan_t second = WIFI_SECOND_CHAN_NONE;
    if (esp_wifi_get_channel(&primary, &second) == ESP_OK) {
        if (ch) *ch = primary;
        if (bw) *bw = (second == WIFI_SECOND_CHAN_NONE) ? 20 : 40;
    }
    return ESP_OK;
}

void wifi_mgr_sta_ip(char *buf, size_t n)
{
    if (buf == NULL || n == 0) return;
    buf[0] = '\0';
    if (s_sta_netif == NULL) return;
    esp_netif_ip_info_t ip;
    if (esp_netif_get_ip_info(s_sta_netif, &ip) == ESP_OK) {
        snprintf(buf, n, IPSTR, IP2STR(&ip.ip));
    }
}

int wifi_mgr_ap_client_count(void) { return s_ap_clients; }

/* ------------------------------------------------------------------ */
/* 扫描                                                                */
/* ------------------------------------------------------------------ */
esp_err_t wifi_mgr_scan(relay_scan_entry_t *out, int max, int *count)
{
    if (out == NULL || count == NULL || max <= 0) return ESP_ERR_INVALID_ARG;
    *count = 0;

    wifi_scan_config_t sc;
    memset(&sc, 0, sizeof(sc));
    sc.show_hidden = true;

    /* 阻塞扫描 */
    esp_err_t err = esp_wifi_scan_start(&sc, true);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "scan start failed: %s", esp_err_to_name(err));
        return err;
    }

    uint16_t num = 0;
    esp_wifi_scan_get_ap_num(&num);
    if (num == 0) {
        esp_wifi_clear_ap_list();
        ESP_LOGW(TAG, "scan: 0 ap");
        return ESP_OK;
    }
    if (num > RELAY_SCAN_MAX) num = RELAY_SCAN_MAX;

    wifi_ap_record_t *recs = calloc(num, sizeof(wifi_ap_record_t));
    if (recs == NULL) {
        esp_wifi_clear_ap_list();
        return ESP_ERR_NO_MEM;
    }

    uint16_t got = num;
    err = esp_wifi_scan_get_ap_records(&got, recs);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "scan get failed: %s", esp_err_to_name(err));
        free(recs);
        esp_wifi_clear_ap_list();
        return err;
    }

    int n = 0;
    for (int i = 0; i < got && n < max; ++i) {
        if (recs[i].ssid[0] == '\0') continue;   /* 跳过隐藏 SSID */
        relay_scan_entry_t *e = &out[n++];
        memset(e, 0, sizeof(*e));
        relay_str_copy(e->ssid, sizeof(e->ssid), (const char *)recs[i].ssid);
        memcpy(e->bssid, recs[i].bssid, 6);
        e->rssi    = recs[i].rssi;
        e->channel = recs[i].primary;
        e->auth    = (uint8_t)recs[i].authmode;
    }
    free(recs);
    esp_wifi_clear_ap_list();

    *count = n;
    ESP_LOGI(TAG, "scan done: %d ap", n);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* NAPT / DNS                                                          */
/* ------------------------------------------------------------------ */
esp_err_t wifi_mgr_napt_set(bool on)
{
    if (s_ap_netif == NULL) return ESP_ERR_INVALID_STATE;

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0)
    esp_err_t err = on ? esp_netif_napt_enable(s_ap_netif)
                       : esp_netif_napt_disable(s_ap_netif);
    if (err == ESP_OK) {
        s_napt = on;
    } else {
        ESP_LOGE(TAG, "napt %s failed: %s", on ? "enable" : "disable",
                 esp_err_to_name(err));
    }
    return err;
#else
    (void)on;
    ESP_LOGE(TAG, "NAPT needs ESP-IDF >= 5.0");
    return ESP_ERR_NOT_SUPPORTED;
#endif
}

bool wifi_mgr_napt_on(void) { return s_napt; }

esp_err_t wifi_mgr_ap_set_dns(const char *dns1, const char *dns2)
{
    if (s_ap_netif == NULL) return ESP_ERR_INVALID_STATE;

    esp_netif_dhcps_stop(s_ap_netif);

    esp_netif_dns_info_t d;
    memset(&d, 0, sizeof(d));
    d.ip.type = ESP_IPADDR_TYPE_V4;

    if (dns1) {
        uint32_t a1 = esp_ip4addr_aton(dns1);      /* 返回网络字节序 uint32_t，0 表示非法 */
        if (a1) {
            d.ip.u_addr.ip4.addr = a1;
            esp_netif_set_dns_info(s_ap_netif, ESP_NETIF_DNS_MAIN, &d);
        }
    }
    if (dns2) {
        uint32_t a2 = esp_ip4addr_aton(dns2);
        if (a2) {
            d.ip.u_addr.ip4.addr = a2;
            esp_netif_set_dns_info(s_ap_netif, ESP_NETIF_DNS_BACKUP, &d);
        }
    }

    uint8_t enable = 1;
    esp_err_t err = esp_netif_dhcps_option(s_ap_netif, ESP_NETIF_OP_SET,
                                           ESP_NETIF_DOMAIN_NAME_SERVER,
                                           &enable, sizeof(enable));
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "dhcps dns option failed: %s", esp_err_to_name(err));
    }

    err = esp_netif_dhcps_start(s_ap_netif);
    ESP_LOGI(TAG, "AP dns -> %s / %s", dns1 ? dns1 : "-", dns2 ? dns2 : "-");
    return err;
}
