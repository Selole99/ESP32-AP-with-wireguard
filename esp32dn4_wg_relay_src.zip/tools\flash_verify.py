#!/usr/bin/env python3
"""分块烧写 + 逐块回读校验（应对 CP210x/线材不稳导致的整包写入截断）。

用法: python tools/flash_verify.py COM9
流程:
  1) 反复尝试连接，等待板子进入下载模式（按住 BOOT 点 RST）
  2) erase_flash
  3) 以 64KB 为单位 write_flash，每块写完立刻 read_flash 回读比对
  4) 任一块失败就重试该块，全部通过后 hard reset
"""
import subprocess
import sys
import time
from pathlib import Path

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM9"
BAUD = sys.argv[2] if len(sys.argv) > 2 else "115200"
TIMEOUT = int(sys.argv[3]) if len(sys.argv) > 3 else 900
PY = sys.executable

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
APP = BUILD / "esp32dn4_wg_relay.bin"
BOOT = BUILD / "bootloader" / "bootloader.bin"
PT = BUILD / "partition_table" / "partition-table.bin"

APP_OFF = 0x10000
CHUNK = 0x10000  # 64KB

BASE = [PY, "-m", "esptool", "--chip", "esp32", "-p", PORT, "-b", BAUD,
        "--before", "no_reset", "--after", "no_reset"]


def run(args, quiet=True):
    r = subprocess.run(BASE + args, capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    if not quiet:
        print(out)
    return r.returncode, out


def wait_download_mode(timeout_s=None):
    print("等待下载模式（按住 BOOT，点一下 RST，松开 RST 再松开 BOOT）...")
    timeout_s = timeout_s or TIMEOUT
    t0 = time.time()
    n = 0
    while time.time() - t0 < timeout_s:
        n += 1
        rc, out = run(["chip_id"])   # esptool v4 用下划线
        if "Chip is ESP32" in out:
            print("已连接: %s" % [l for l in out.splitlines() if "Chip is" in l][0].strip())
            return True
        if n % 20 == 0:
            print("  ... 第 %d 次尝试，仍未进入下载模式 (%.0fs)" % (n, time.time() - t0))
        time.sleep(2)
    print("超时：没等到下载模式")
    return False


def write_chunk(path, offset, data: bytes):
    tmp = Path("C:/esp/_chunk.bin")
    tmp.write_bytes(data)
    for attempt in range(1, 4):
        rc, out = run(["write_flash", "--flash_mode", "dio", "--flash_size", "4MB",
                       "--flash_freq", "40m", hex(offset), str(tmp)])
        if rc == 0 and "Hash of data verified" in out:
            return True
        print("    chunk @%#x 写入失败(第%d次): %s" % (offset, attempt, out.strip().splitlines()[-1][:100]))
        time.sleep(1)
    return False


def verify_chunk(offset, data: bytes):
    tmp = Path("C:/esp/_read.bin")
    rc, out = run(["read_flash", hex(offset), str(len(data)), str(tmp)])
    if rc != 0 or not tmp.exists():
        return False, -1
    got = tmp.read_bytes()
    if got == data:
        return True, -1
    for i in range(min(len(got), len(data))):
        if got[i] != data[i]:
            return False, i
    return False, min(len(got), len(data))


def main():
    for f in (APP, BOOT, PT):
        if not f.exists():
            print("缺少文件:", f)
            return 1

    app = APP.read_bytes()
    print("app: %s (%d bytes), bootloader %d, partition-table %d"
          % (APP.name, len(app), BOOT.stat().st_size, PT.stat().st_size))

    while not wait_download_mode():
        print("再按一次 BOOT + RST 试试？(继续等待 60s)")
        time.sleep(1)

    print("擦除 flash ...")
    rc, out = run(["erase_flash"], quiet=False)
    print("erase rc=%d" % rc)

    print("写 bootloader + 分区表 ...")
    rc, out = run(["write_flash", "--flash_mode", "dio", "--flash_size", "4MB",
                   "--flash_freq", "40m",
                   "0x1000", str(BOOT), "0x8000", str(PT)], quiet=False)

    total = len(app)
    ok = True
    for off in range(0, total, CHUNK):
        data = app[off:off + CHUNK]
        addr = APP_OFF + off
        print("块 %#x (%d/%d)" % (addr, off + len(data), total))
        good = False
        for attempt in range(1, 4):
            if not write_chunk(APP, addr, data):
                continue
            match, diff = verify_chunk(addr, data)
            if match:
                good = True
                break
            print("    回读不一致 @%#x (diff at +%d)，重写" % (addr, diff))
        if not good:
            ok = False
            print("块 %#x 始终失败" % addr)
            break

    if ok:
        print("== 全部写入并校验通过 ==")
        run(["run"])
    else:
        print("== 烧写未完成 ==")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
