#!/usr/bin/env python3
"""抓 COM9 串口日志（带 ESP32 复位时序），不依赖 idf.py monitor。

用法: python tools/serial_log.py COM9 115200 12
"""
import sys
import time

import serial

port = sys.argv[1] if len(sys.argv) > 1 else "COM9"
baud = int(sys.argv[2]) if len(sys.argv) > 2 else 115200
dur = float(sys.argv[3]) if len(sys.argv) > 3 else 12.0

s = serial.Serial(port, baud, timeout=0.2)
no_reset = "--no-reset" in sys.argv
if no_reset:
    # USB-Serial/JTAG 板子(DTR/RTS 一拉就进下载模式)：只读，不碰控制线
    s.dtr = False
    s.rts = False
    time.sleep(0.3)
else:
    # 经典 ESP32 自动复位: EN=RTS, IO0=DTR
    s.setDTR(False)
    s.setRTS(True)
    time.sleep(0.15)
    s.setRTS(False)
    time.sleep(0.1)

end = time.time() + dur
buf = b""
while time.time() < end:
    chunk = s.read(4096)
    if chunk:
        buf += chunk
s.close()

sys.stdout.write(buf.decode("utf-8", "replace"))
print("\n--- captured %d bytes ---" % len(buf))
