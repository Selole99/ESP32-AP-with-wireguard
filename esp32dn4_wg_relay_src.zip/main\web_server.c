/*
 * web_server.c - 配置用 HTTP 服务（手机/电脑浏览器访问 http://192.168.4.1/）
 *
 * 请求体统一使用 application/x-www-form-urlencoded（无需 cJSON 依赖）。
 * JS 里用 encodeURIComponent，base64 里的 '+' '/' '=' 都会被正确转义。
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>

#include "sdkconfig.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "app_config.h"
#include "config_store.h"
#include "wifi_mgr.h"
#include "wg_mgr.h"
#include "time_sync.h"
#include "web_server.h"

static const char *TAG = "web";

extern const uint8_t index_html_start[] asm("_binary_index_html_start");
extern const uint8_t index_html_end[]   asm("_binary_index_html_end");

/* ------------------------------------------------------------------ */
/* 小工具                                                              */
/* ------------------------------------------------------------------ */
typedef struct {
    char  *buf;
    size_t len;
    size_t cap;
} sb_t;

static void sb_init(sb_t *sb, size_t cap)
{
    sb->buf = malloc(cap);
    sb->len = 0;
    sb->cap = sb->buf ? cap : 0;
    if (sb->buf) sb->buf[0] = '\0';
}

static void sb_free(sb_t *sb)
{
    free(sb->buf);
    sb->buf = NULL;
    sb->len = sb->cap = 0;
}

static bool sb_reserve(sb_t *sb, size_t extra)
{
    if (sb->buf == NULL) return false;
    if (sb->len + extra + 1 <= sb->cap) return true;
    size_t ncap = sb->cap * 2;
    while (ncap < sb->len + extra + 1) ncap *= 2;
    char *n = realloc(sb->buf, ncap);
    if (n == NULL) return false;
    sb->buf = n;
    sb->cap = ncap;
    return true;
}

static bool sb_puts(sb_t *sb, const char *s)
{
    size_t l = strlen(s);
    if (!sb_reserve(sb, l)) return false;
    memcpy(sb->buf + sb->len, s, l + 1);
    sb->len += l;
    return true;
}

static bool sb_printf(sb_t *sb, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    char tmp[512];
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n < 0) return false;
    if (n >= (int)sizeof(tmp)) {
        if (!sb_reserve(sb, (size_t)n)) return false;
        va_start(ap, fmt);
        vsnprintf(sb->buf + sb->len, (size_t)n + 1, fmt, ap);
        va_end(ap);
        sb->len += (size_t)n;
        return true;
    }
    if (!sb_reserve(sb, (size_t)n)) return false;
    memcpy(sb->buf + sb->len, tmp, (size_t)n + 1);
    sb->len += (size_t)n;
    return true;
}

/* JSON 字符串转义（UTF-8 原样保留） */
static void json_escape(const char *in, char *out, size_t n)
{
    size_t o = 0;
    if (n == 0) return;
    for (size_t i = 0; in[i] && o + 7 < n; ++i) {
        unsigned char c = (unsigned char)in[i];
        if (c == '"' || c == '\\') {
            out[o++] = '\\';
            out[o++] = (char)c;
        } else if (c == '\n') {
            out[o++] = '\\'; out[o++] = 'n';
        } else if (c == '\r') {
            out[o++] = '\\'; out[o++] = 'r';
        } else if (c == '\t') {
            out[o++] = '\\'; out[o++] = 't';
        } else if (c < 0x20) {
            o += (size_t)snprintf(out + o, n - o, "\\u%04x", c);
        } else {
            out[o++] = (char)c;
        }
    }
    out[o] = '\0';
}

static void send_json(httpd_req_t *req, const char *status, const char *body)
{
    httpd_resp_set_status(req, status);
    httpd_resp_set_type(req, "application/json; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    httpd_resp_send(req, body, HTTPD_RESP_USE_STRLEN);
}

static void send_err(httpd_req_t *req, const char *msg)
{
    char body[256];
    char esc[200];
    json_escape(msg, esc, sizeof(esc));
    snprintf(body, sizeof(body), "{\"ok\":false,\"msg\":\"%s\"}", esc);
    send_json(req, "400 Bad Request", body);
}

static void send_ok(httpd_req_t *req, const char *extra)
{
    char body[256];
    snprintf(body, sizeof(body), "{\"ok\":true%s%s}", extra ? "," : "",
             extra ? extra : "");
    send_json(req, "200 OK", body);
}

static esp_err_t read_body(httpd_req_t *req, char *buf, size_t buflen)
{
    if (req->content_len == 0) { buf[0] = '\0'; return ESP_OK; }
    if (req->content_len >= buflen) return ESP_ERR_INVALID_SIZE;

    int total = 0;
    while (total < (int)req->content_len) {
        int r = httpd_req_recv(req, buf + total, req->content_len - total);
        if (r <= 0) {
            if (r == HTTPD_SOCK_ERR_TIMEOUT) continue;
            return ESP_FAIL;
        }
        total += r;
    }
    buf[total] = '\0';
    return ESP_OK;
}

static void url_decode(char *s)
{
    char *d = s;
    while (*s) {
        if (*s == '%' && s[1] && s[2]) {
            char hex[3] = { s[1], s[2], 0 };
            *d++ = (char)strtol(hex, NULL, 16);
            s += 3;
        } else if (*s == '+') {
            *d++ = ' ';
            s++;
        } else {
            *d++ = *s++;
        }
    }
    *d = '\0';
}

/* 在表单串中取 key 的值
 * 注意：必须先解码到临时缓冲区，再按目标字段长度拷贝。
 * URL 编码后长度可能是原文的 3 倍（'+'->%2B、'='->%3D、'/'->%2F），
 * 若直接解码进目标字段，44 字节 base64 密钥（编码后 48 字符）会被截断。
 */
#define RELAY_FORM_TMP 512
static bool form_get(const char *body, const char *key, char *out, size_t n)
{
    size_t klen = strlen(key);
    const char *p = body;
    while (p && *p) {
        const char *amp  = strchr(p, '&');
        const char *end  = amp ? amp : p + strlen(p);
        const char *eq   = memchr(p, '=', (size_t)(end - p));
        if (eq && (size_t)(eq - p) == klen && strncmp(p, key, klen) == 0) {
            size_t vlen = (size_t)(end - eq - 1);
            if (vlen >= RELAY_FORM_TMP) vlen = RELAY_FORM_TMP - 1;
            char tmp[RELAY_FORM_TMP];
            memcpy(tmp, eq + 1, vlen);
            tmp[vlen] = '\0';
            url_decode(tmp);
            relay_str_copy(out, n, tmp);
            return true;
        }
        if (!amp) break;
        p = amp + 1;
    }
    return false;
}

static int form_get_int(const char *body, const char *key, int def)
{
    char tmp[16];
    if (!form_get(body, key, tmp, sizeof(tmp))) return def;
    return atoi(tmp);
}

static bool form_get_bool(const char *body, const char *key, bool def)
{
    char tmp[8];
    if (!form_get(body, key, tmp, sizeof(tmp))) return def;
    return (tmp[0] == '1' || tmp[0] == 't' || tmp[0] == 'T' || tmp[0] == 'y');
}

static void restart_later_cb(void *arg)
{
    (void)arg;
    ESP_LOGW(TAG, "rebooting now");
    esp_restart();
}

static void reboot_in_ms(uint32_t ms)
{
    esp_timer_handle_t t;
    const esp_timer_create_args_t a = {
        .callback = restart_later_cb,
        .name     = "reboot",
    };
    if (esp_timer_create(&a, &t) == ESP_OK) {
        esp_timer_start_once(t, (uint64_t)ms * 1000ULL);
    }
}

/* ------------------------------------------------------------------ */
/* 页面                                                                */
/* ------------------------------------------------------------------ */
static esp_err_t h_index(httpd_req_t *req)
{
    const size_t len = (size_t)(index_html_end - index_html_start);
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache");
    return httpd_resp_send(req, (const char *)index_html_start, len);
}

/* ------------------------------------------------------------------ */
/* /api/status                                                         */
/* ------------------------------------------------------------------ */
static esp_err_t h_status(httpd_req_t *req)
{
    static char body[1600];
    char ip[20] = "-";
    char now[32] = "-";
    char ssid[80];
    char ap_ssid[80];
    char wg_ep[120];
    char tip[20] = "-";
    char phy[8] = "-";
    uint8_t ch = 0, bw = 0;
    uint32_t tx_bps = 0, rx_bps = 0;

    wifi_mgr_sta_ip(ip, sizeof(ip));
    time_sync_now_str(now, sizeof(now));
    json_escape(config_get()->sta.ssid, ssid, sizeof(ssid));
    json_escape(config_get()->ap.ssid, ap_ssid, sizeof(ap_ssid));
    json_escape(config_get()->wg.endpoint, wg_ep, sizeof(wg_ep));
    wg_mgr_tunnel_ip(tip, sizeof(tip));
    wifi_mgr_sta_radio(phy, sizeof(phy), &ch, &bw);
    wg_mgr_traffic_rates(&tx_bps, &rx_bps);

    snprintf(body, sizeof(body),
        "{"
        "\"sta\":{\"ssid\":\"%s\",\"connected\":%s,\"has_ip\":%s,\"ip\":\"%s\",\"rssi\":%d,\"ch\":%u,\"bw\":%u,\"phy\":\"%s\"},"
        "\"ap\":{\"ssid\":\"%s\",\"ip\":\"" RELAY_AP_IP "\",\"clients\":%d,\"client_rssi\":%d},"
        "\"wg\":{\"state\":\"%s\",\"up\":%s,\"handshake\":%s,\"endpoint\":\"%s\",\"error\":\"%s\",\"available\":%s,\"tunnel_ip\":\"%s\",\"tx_bps\":%u,\"rx_bps\":%u},"
        "\"time\":{\"synced\":%s,\"source\":\"%s\",\"now\":\"%s\",\"epoch\":%lld,\"tz\":\"%s\"},"
        "\"napt\":%s,"
        "\"heap\":%u,"
        "\"uptime\":%lld,"
        "\"wg_enabled\":%s,"
        "\"reboot_hours\":%u"
        "}",
        ssid,
        wifi_mgr_sta_connected() ? "true" : "false",
        wifi_mgr_sta_has_ip() ? "true" : "false",
        ip,
        (int)wifi_mgr_sta_rssi(),
        (unsigned)ch, (unsigned)bw, phy,
        ap_ssid,
        wifi_mgr_ap_client_count(),
        (int)wifi_mgr_ap_client_rssi(),
        wg_mgr_state_str(),
        wg_mgr_is_up() ? "true" : "false",
        wg_mgr_peer_up() ? "true" : "false",
        wg_ep,
        wg_mgr_last_error(),
        wg_mgr_available() ? "true" : "false",
        tip,
        (unsigned)tx_bps, (unsigned)rx_bps,
        time_sync_ready() ? "true" : "false",
        time_sync_source_str(),
        now,
        (long long)time_sync_epoch(),
        config_get()->time.tz,
        wifi_mgr_napt_on() ? "true" : "false",
        (unsigned)esp_get_free_heap_size(),
        (long long)(esp_timer_get_time() / 1000000LL),
        config_get()->wg.enabled ? "true" : "false",
        (unsigned)config_reboot_hours());

    send_json(req, "200 OK", body);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/config                                                         */
/* ------------------------------------------------------------------ */
static esp_err_t h_config_get(httpd_req_t *req)
{
    const relay_cfg_t *c = config_get();
    sb_t sb;
    sb_init(&sb, 1024);
    if (sb.buf == NULL) {
        send_err(req, "oom");
        return ESP_OK;
    }

    char e_ssid[80], e_pass[140], e_priv[64], e_pub[64], e_psk[64],
         e_ep[140], e_ap_ssid[80], e_ap_pass[140], e_tz[64];

    json_escape(c->sta.ssid, e_ssid, sizeof(e_ssid));
    json_escape(c->sta.pass, e_pass, sizeof(e_pass));
    json_escape(c->wg.priv, e_priv, sizeof(e_priv));
    json_escape(c->wg.peer_pub, e_pub, sizeof(e_pub));
    json_escape(c->wg.psk, e_psk, sizeof(e_psk));
    json_escape(c->wg.endpoint, e_ep, sizeof(e_ep));
    json_escape(c->ap.ssid, e_ap_ssid, sizeof(e_ap_ssid));
    json_escape(c->ap.pass, e_ap_pass, sizeof(e_ap_pass));
    json_escape(c->time.tz, e_tz, sizeof(e_tz));

    sb_printf(&sb, "{\"ok\":true,");
    sb_printf(&sb, "\"sta\":{\"ssid\":\"%s\",\"password\":\"%s\",\"auth\":%u},",
              e_ssid, e_pass, (unsigned)c->sta.auth);
    sb_printf(&sb, "\"ap\":{\"ssid\":\"%s\",\"password\":\"%s\",\"auth\":%u,\"channel\":%u,\"hidden\":%s},",
              e_ap_ssid, e_ap_pass, (unsigned)c->ap.auth,
              (unsigned)c->ap.channel, c->ap.hidden ? "true" : "false");
    sb_printf(&sb, "\"wg\":{\"enabled\":%s,\"private_key\":\"%s\",\"peer_public_key\":\"%s\","
                   "\"preshared_key\":\"%s\",\"endpoint\":\"%s\",\"tunnel_ip\":\"%s\","
                   "\"tunnel_mask\":\"%s\",\"listen_port\":%u,\"keepalive\":%u,"
                   "\"mtu\":%u,\"dns1\":\"%s\",\"dns2\":\"%s\"},",
              c->wg.enabled ? "true" : "false", e_priv, e_pub, e_psk, e_ep,
              c->wg.tunnel_ip, c->wg.tunnel_mask,
              (unsigned)c->wg.listen_port, (unsigned)c->wg.keepalive,
              (unsigned)c->wg.mtu, c->wg.dns1, c->wg.dns2);
    sb_printf(&sb, "\"time\":{\"tz\":\"%s\",\"allow_sntp\":%s}}",
              e_tz, c->time.allow_sntp_bootstrap ? "true" : "false");

    send_json(req, "200 OK", sb.buf);
    sb_free(&sb);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/scan                                                           */
/* ------------------------------------------------------------------ */
static esp_err_t h_scan(httpd_req_t *req)
{
    relay_scan_entry_t *list = calloc(RELAY_SCAN_MAX, sizeof(*list));
    if (list == NULL) {
        send_err(req, "no memory");
        return ESP_OK;
    }

    int n = 0;
    esp_err_t err = wifi_mgr_scan(list, RELAY_SCAN_MAX, &n);
    if (err != ESP_OK) {
        free(list);
        send_err(req, esp_err_to_name(err));
        return ESP_OK;
    }

    sb_t sb;
    sb_init(&sb, 1024);
    sb_puts(&sb, "{\"ok\":true,\"count\":");
    sb_printf(&sb, "%d,\"list\":[", n);
    for (int i = 0; i < n; ++i) {
        char es[140];
        json_escape(list[i].ssid, es, sizeof(es));
        sb_printf(&sb,
            "%s{\"ssid\":\"%s\",\"rssi\":%d,\"ch\":%u,\"auth\":%u,"
            "\"mac\":\"%02x:%02x:%02x:%02x:%02x:%02x\"}",
            i ? "," : "", es, (int)list[i].rssi, (unsigned)list[i].channel,
            (unsigned)list[i].auth,
            list[i].bssid[0], list[i].bssid[1], list[i].bssid[2],
            list[i].bssid[3], list[i].bssid[4], list[i].bssid[5]);
    }
    sb_puts(&sb, "]}");
    free(list);

    send_json(req, "200 OK", sb.buf ? sb.buf : "{\"ok\":false}");
    sb_free(&sb);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/time  —— 从浏览器取时间（WG 上线的前置条件）                    */
/* ------------------------------------------------------------------ */
static esp_err_t h_time(httpd_req_t *req)
{
    char body[256];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }

    char tmp[40] = { 0 };
    if (!form_get(body, "epoch_ms", tmp, sizeof(tmp))) {
        send_err(req, "epoch_ms required");
        return ESP_OK;
    }
    int64_t ms = (int64_t)strtoll(tmp, NULL, 10);

    char tz[RELAY_TZ_MAX] = { 0 };
    if (!form_get(body, "tz", tz, sizeof(tz)) || tz[0] == '\0') {
        relay_str_copy(tz, sizeof(tz), config_get()->time.tz);
    }

    esp_err_t err = time_sync_set_from_browser(ms, tz);
    if (err != ESP_OK) {
        send_err(req, "invalid browser time");
        return ESP_OK;
    }

    /* 时间已就绪：立刻尝试拉起隧道（用户停用 WG 时不自动上线） */
    char extra[64] = { 0 };
    if (config_get()->wg.enabled && !wg_mgr_user_stopped() && wg_mgr_up_async() == ESP_OK) {
        snprintf(extra, sizeof(extra), "\"wg_starting\":true");
    }
    send_ok(req, extra[0] ? extra : NULL);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/sta                                                            */
/* ------------------------------------------------------------------ */
static esp_err_t h_sta(httpd_req_t *req)
{
    char body[512];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }

    relay_cfg_t c = *config_get();
    if (!form_get(body, "ssid", c.sta.ssid, sizeof(c.sta.ssid)) || c.sta.ssid[0] == '\0') {
        send_err(req, "ssid required");
        return ESP_OK;
    }
    if (!form_get(body, "password", c.sta.pass, sizeof(c.sta.pass))) {
        c.sta.pass[0] = '\0';
    }
    c.sta.auth = (uint8_t)form_get_int(body, "auth", RELAY_AUTH_WPA2_PSK);
    if (c.sta.auth > RELAY_AUTH_WPA2_WPA3_PSK) c.sta.auth = RELAY_AUTH_WPA2_PSK;

    if (c.sta.auth != RELAY_AUTH_OPEN && strlen(c.sta.pass) < 8) {
        send_err(req, "WiFi 密码至少 8 位（开放网络请选 OPEN）");
        return ESP_OK;
    }
    if (c.sta.auth != RELAY_AUTH_OPEN && strlen(c.sta.pass) > 63) {
        send_err(req, "WiFi 密码最多 63 位");
        return ESP_OK;
    }

    if (config_save(&c) != ESP_OK) {
        send_err(req, "save failed");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "STA config saved: '%s' auth=%u", c.sta.ssid, (unsigned)c.sta.auth);

    send_ok(req, "\"reboot\":true");
    reboot_in_ms(1200);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/ap                                                             */
/* ------------------------------------------------------------------ */
static esp_err_t h_ap(httpd_req_t *req)
{
    char body[512];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }

    relay_cfg_t c = *config_get();
    if (!form_get(body, "ssid", c.ap.ssid, sizeof(c.ap.ssid)) || c.ap.ssid[0] == '\0') {
        send_err(req, "热点名称不能为空");
        return ESP_OK;
    }
    if (!form_get(body, "password", c.ap.pass, sizeof(c.ap.pass))) c.ap.pass[0] = '\0';
    c.ap.auth    = (uint8_t)form_get_int(body, "auth", RELAY_AUTH_WPA2_PSK);
    c.ap.channel = (uint8_t)form_get_int(body, "channel", RELAY_AP_DEF_CHAN);
    c.ap.hidden  = form_get_bool(body, "hidden", false);

    if (c.ap.channel < 1 || c.ap.channel > 13) c.ap.channel = RELAY_AP_DEF_CHAN;
    if (c.ap.auth != RELAY_AUTH_OPEN && strlen(c.ap.pass) < 8) {
        send_err(req, "热点密码至少 8 位（开放网络请选 OPEN）");
        return ESP_OK;
    }

    if (config_save(&c) != ESP_OK) {
        send_err(req, "save failed");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "AP config saved: '%s'", c.ap.ssid);

    send_ok(req, "\"reboot\":true");
    reboot_in_ms(1500);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/wg                                                             */
/* ------------------------------------------------------------------ */
static esp_err_t h_wg(httpd_req_t *req)
{
    char body[1024];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "wg POST len=%u body=[%s]", (unsigned)strlen(body), body);

    relay_cfg_t c = *config_get();
    form_get(body, "private_key", c.wg.priv, sizeof(c.wg.priv));
    form_get(body, "peer_public_key", c.wg.peer_pub, sizeof(c.wg.peer_pub));
    form_get(body, "preshared_key", c.wg.psk, sizeof(c.wg.psk));
    form_get(body, "endpoint", c.wg.endpoint, sizeof(c.wg.endpoint));
    form_get(body, "tunnel_ip", c.wg.tunnel_ip, sizeof(c.wg.tunnel_ip));
    form_get(body, "tunnel_mask", c.wg.tunnel_mask, sizeof(c.wg.tunnel_mask));
    form_get(body, "dns1", c.wg.dns1, sizeof(c.wg.dns1));
    form_get(body, "dns2", c.wg.dns2, sizeof(c.wg.dns2));
    c.wg.listen_port = (uint16_t)form_get_int(body, "listen_port", c.wg.listen_port);
    c.wg.keepalive   = (uint16_t)form_get_int(body, "keepalive", c.wg.keepalive);
    c.wg.mtu         = (uint16_t)form_get_int(body, "mtu", c.wg.mtu);
    c.wg.enabled     = form_get_bool(body, "enabled", c.wg.enabled);

    /* 前端留空表示"保持原值" */
    if (c.wg.psk[0] == '\0') {
        relay_str_copy(c.wg.psk, sizeof(c.wg.psk),
                       "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
    }
    if (c.wg.tunnel_ip[0] == '\0')
        relay_str_copy(c.wg.tunnel_ip, sizeof(c.wg.tunnel_ip), "10.66.66.3");
    if (c.wg.tunnel_mask[0] == '\0')
        relay_str_copy(c.wg.tunnel_mask, sizeof(c.wg.tunnel_mask), "255.255.255.0");

    ESP_LOGI(TAG, "parsed: priv_len=%u priv=[%s] peer_len=%u psk_len=%u ep=[%s]",
             (unsigned)strlen(c.wg.priv), c.wg.priv,
             (unsigned)strlen(c.wg.peer_pub), (unsigned)strlen(c.wg.psk), c.wg.endpoint);

    char msg[96];
    if (wg_mgr_validate(&c.wg, msg, sizeof(msg)) != ESP_OK) {
        send_err(req, msg);
        return ESP_OK;
    }
    if (config_save(&c) != ESP_OK) {
        send_err(req, "save failed");
        return ESP_OK;
    }
    ESP_LOGI(TAG, "WG config saved: ep='%s' enabled=%d", c.wg.endpoint, c.wg.enabled);

    /*
     * 不原地销毁/重建 WG 网卡：保存时手机通常正在走流量，lwIP 的
     * tcpip 线程还在用这块 netif，netif_remove + netif_add 不在该线程里
     * 执行会破坏转发状态（表现为“已连接、NAT 开着但上不了网”）。
     * WG 参数本来就只在启动时读取，重启一次最干净。
     */
    send_ok(req, "\"applied\":true,\"reboot\":true");
    reboot_in_ms(1200);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/wgctl   action=up|down|restart                                 */
/* ------------------------------------------------------------------ */
static esp_err_t h_wgctl(httpd_req_t *req)
{
    char body[128];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }
    char action[16] = { 0 };
    if (!form_get(body, "action", action, sizeof(action))) {
        send_err(req, "action required");
        return ESP_OK;
    }

    if (strcmp(action, "up") == 0) {
        if (!config_get()->wg.enabled) {
            send_err(req, "WireGuard 已停用，请先启用");
            return ESP_OK;
        }
        wg_mgr_set_user_stopped(false);
        esp_err_t err = wg_mgr_up_async();
        if (err != ESP_OK) {
            send_err(req, wg_mgr_last_error());
            return ESP_OK;
        }
        send_ok(req, "\"starting\":true");
    } else if (strcmp(action, "down") == 0) {
        wg_mgr_set_user_stopped(true);
        wg_mgr_stop();
        wifi_mgr_napt_set(false);
        send_ok(req, "\"stopped\":true");
    } else if (strcmp(action, "restart") == 0) {
        if (!config_get()->wg.enabled) {
            send_err(req, "WireGuard 已停用，请先启用");
            return ESP_OK;
        }
        wg_mgr_set_user_stopped(false);
        /* 原地重建 netif 会和在途流量抢 lwIP 状态，重启最稳 */
        send_ok(req, "\"reboot\":true");
        reboot_in_ms(1000);
    } else if (strcmp(action, "enable") == 0) {
        /* 启用 WireGuard（允许自动上线）：写配置后重启，避免原地重建网卡 */
        relay_cfg_t c = *config_get();
        c.wg.enabled = true;
        config_save(&c);
        wg_mgr_set_user_stopped(false);
        send_ok(req, "\"enabled\":true,\"reboot\":true");
        reboot_in_ms(1000);
    } else if (strcmp(action, "disable") == 0) {
        /* 停用 WireGuard：写配置后重启；开机时按 enabled=false 不建隧道、不开 NAT */
        relay_cfg_t c = *config_get();
        c.wg.enabled = false;
        config_save(&c);
        wg_mgr_set_user_stopped(true);
        send_ok(req, "\"enabled\":false,\"reboot\":true");
        reboot_in_ms(1000);
    } else {
        send_err(req, "unknown action");
    }
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/misc   action=reboot|factory                                   */
/* ------------------------------------------------------------------ */
static esp_err_t h_misc(httpd_req_t *req)
{
    char body[128];
    if (read_body(req, body, sizeof(body)) != ESP_OK) {
        send_err(req, "bad body");
        return ESP_OK;
    }
    char action[16] = { 0 };
    if (!form_get(body, "action", action, sizeof(action))) {
        send_err(req, "action required");
        return ESP_OK;
    }

    if (strcmp(action, "reboot") == 0) {
        send_ok(req, "\"reboot\":true");
        reboot_in_ms(800);
    } else if (strcmp(action, "factory") == 0) {
        config_reset();
        send_ok(req, "\"reboot\":true");
        reboot_in_ms(800);
    } else if (strcmp(action, "reboot_hours") == 0) {
        /* 定时重启间隔（小时），0=关闭 */
        int hours = form_get_int(body, "value", -1);
        if (hours < 0 || hours > 168) {
            send_err(req, "value must be 0..168 hours");
            return ESP_OK;
        }
        esp_err_t err = config_set_reboot_hours((uint8_t)hours);
        if (err != ESP_OK) { send_err(req, "save failed"); return ESP_OK; }
        char extra[48];
        snprintf(extra, sizeof(extra), "\"reboot_hours\":%d", hours);
        send_ok(req, extra);
    } else {
        send_err(req, "unknown action");
    }
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/probe  隧道自检                                                */
/* ------------------------------------------------------------------ */
static esp_err_t h_probe(httpd_req_t *req)
{
    char body[256];
    read_body(req, body, sizeof(body));

    char ip[32] = "1.1.1.1";
    form_get(body, "ip", ip, sizeof(ip));
    int port = form_get_int(body, "port", 80);

    esp_err_t err = wg_mgr_probe(ip, port, 4000);
    char out[160];
    snprintf(out, sizeof(out),
             "{\"ok\":%s,\"target\":\"%s:%d\",\"err\":\"%s\",\"state\":\"%s\",\"handshake\":%s}",
             err == ESP_OK ? "true" : "false", ip, port, esp_err_to_name(err),
             wg_mgr_state_str(), wg_mgr_peer_up() ? "true" : "false");
    send_json(req, "200 OK", out);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* 404 → 强制门户跳转                                                  */
/* ------------------------------------------------------------------ */
static esp_err_t err_404(httpd_req_t *req, httpd_err_code_t code)
{
    (void)code;
    if (strncmp(req->uri, "/api/", 5) == 0) {
        httpd_resp_set_status(req, "404 Not Found");
        httpd_resp_set_type(req, "application/json");
        httpd_resp_send(req, "{\"ok\":false,\"msg\":\"no such api\"}",
                        HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }
    httpd_resp_set_status(req, "302 Found");
    httpd_resp_set_hdr(req, "Location", "http://" RELAY_AP_IP "/");
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* /api/ota  流式上传固件并切换启动分区                                 */
/* 请求体 = 原始 app 二进制（build/esp32dn4_wg_relay.bin）             */
/* ------------------------------------------------------------------ */
static esp_err_t h_ota(httpd_req_t *req)
{
    if (req->content_len <= 0) {
        send_err(req, "empty body");
        return ESP_OK;
    }

    const esp_partition_t *part = esp_ota_get_next_update_partition(NULL);
    if (part == NULL) {
        send_err(req, "no ota partition (check partitions.csv)");
        return ESP_OK;
    }

    esp_ota_handle_t oh;
    esp_err_t err = esp_ota_begin(part, OTA_SIZE_UNKNOWN, &oh);
    if (err != ESP_OK) {
        send_err(req, "ota_begin failed");
        return ESP_OK;
    }

    static char buf[4096];
    int remaining = (int)req->content_len;
    while (remaining > 0) {
        int r = httpd_req_recv(req, buf, remaining < (int)sizeof(buf) ? remaining : (int)sizeof(buf));
        if (r == HTTPD_SOCK_ERR_TIMEOUT) continue;
        if (r <= 0) {
            esp_ota_abort(oh);
            send_err(req, "receive aborted");
            return ESP_OK;
        }
        err = esp_ota_write(oh, buf, r);
        if (err != ESP_OK) {
            esp_ota_abort(oh);
            send_err(req, "ota_write failed");
            return ESP_OK;
        }
        remaining -= r;
    }

    err = esp_ota_end(oh);
    if (err != ESP_OK) {
        send_err(req, esp_err_to_name(err));
        return ESP_OK;
    }
    err = esp_ota_set_boot_partition(part);
    if (err != ESP_OK) {
        send_err(req, "set_boot_partition failed");
        return ESP_OK;
    }

    ESP_LOGW(TAG, "ota ok, rebooting into new image");
    send_ok(req, "\"reboot\":true");
    reboot_in_ms(1200);
    return ESP_OK;
}

/* ------------------------------------------------------------------ */
/* 注册                                                                */
/* ------------------------------------------------------------------ */
esp_err_t web_server_start(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port      = 80;
    cfg.lru_purge_enable = true;
    cfg.max_uri_handlers = 16;
    cfg.stack_size       = 8192;
    cfg.recv_wait_timeout = 10;
    cfg.send_wait_timeout = 10;
    cfg.core_id = 1;   /* httpd 钉到 CPU1，CPU0 留给 WiFi/lwIP 转发热路径 */

    httpd_handle_t server = NULL;
    esp_err_t err = httpd_start(&server, &cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "httpd_start failed: %s", esp_err_to_name(err));
        return err;
    }

    static const httpd_uri_t uris[] = {
        { .uri = "/",              .method = HTTP_GET,  .handler = h_index },
        { .uri = "/index.html",    .method = HTTP_GET,  .handler = h_index },
        { .uri = "/api/status",    .method = HTTP_GET,  .handler = h_status },
        { .uri = "/api/config",    .method = HTTP_GET,  .handler = h_config_get },
        { .uri = "/api/scan",      .method = HTTP_GET,  .handler = h_scan },
        { .uri = "/api/time",      .method = HTTP_POST, .handler = h_time },
        { .uri = "/api/sta",       .method = HTTP_POST, .handler = h_sta },
        { .uri = "/api/ap",        .method = HTTP_POST, .handler = h_ap },
        { .uri = "/api/wg",        .method = HTTP_POST, .handler = h_wg },
        { .uri = "/api/wgctl",     .method = HTTP_POST, .handler = h_wgctl },
        { .uri = "/api/misc",      .method = HTTP_POST, .handler = h_misc },
        { .uri = "/api/ota",       .method = HTTP_POST, .handler = h_ota },
        { .uri = "/api/probe",     .method = HTTP_POST, .handler = h_probe },
    };
    for (size_t i = 0; i < sizeof(uris) / sizeof(uris[0]); ++i) {
        httpd_register_uri_handler(server, &uris[i]);
    }
    httpd_register_err_handler(server, HTTPD_404_NOT_FOUND, err_404);

    ESP_LOGI(TAG, "http server on :80 (open http://" RELAY_AP_IP "/)");
    return ESP_OK;
}
