#!/usr/bin/env python3
"""烧写链路诊断：等下载模式 -> flash_id -> 4KB 写入回读比对（分别用 stub / ROM loader）。

用法: python tools/diag_flash.py COM9 [115200] [超时秒]
"""
import subprocess
import sys
import time
from pathlib import Path

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM9"
BAUD = sys.argv[2] if len(sys.argv) > 2 else "115200"
TIMEOUT = int(sys.argv[3]) if len(sys.argv) > 3 else 1800
PY = sys.executable

BASE = [PY, "-m", "esptool", "--chip", "esp32", "-p", PORT, "-b", BAUD,
        "--before", "no_reset", "--after", "no_reset"]

PATTERN = Path("C:/esp/_test4k.bin")


def run(args, extra=None):
    cmd = BASE + (extra or []) + args
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, ((r.stdout or "") + (r.stderr or ""))


def wait_download():
    print("等待下载模式：按住 BOOT，插 USB 或点 RST ...")
    t0 = time.time()
    n = 0
    while time.time() - t0 < TIMEOUT:
        n += 1
        rc, out = run(["flash_id"])
        if "Chip is ESP32" in out:
            print("已连接：", [l.strip() for l in out.splitlines() if "Chip is" in l][0])
            # 打印 flash 标识
            for l in out.splitlines():
                if any(k in l for k in ("Manufacturer", "Device", "Detected flash size", "Flash size")):
                    print("   ", l.strip())
            return True
        if n % 15 == 0:
            print("   ... %d 次尝试 (%.0fs)，仍未进入下载模式" % (n, time.time() - t0))
        time.sleep(2)
    print("超时")
    return False


def test_write(label, extra):
    print("\n[%s] 写 4KB 到 0x9000 并回读比对 ..." % label)
    rc, out = run(["write_flash", "--flash_mode", "dio", "--flash_size", "4MB",
                   "0x9000", str(PATTERN)], extra)
    tail = [l for l in out.splitlines() if l.strip()][-4:]
    print("   write rc=%d" % rc, "|", " / ".join(tail))
    rc2, out2 = run(["read_flash", "0x9000", "4096", "C:/esp/_readback.bin"], extra)
    if rc2 == 0 and Path("C:/esp/_readback.bin").exists():
        got = Path("C:/esp/_readback.bin").read_bytes()
        want = PATTERN.read_bytes()
        same = got == want
        print("   回读: %s (%d bytes)" % ("一致 ✔" if same else "不一致 ✘", len(got)))
        if not same:
            diff = next((i for i in range(min(len(got), len(want))) if got[i] != want[i]), -1)
            print("   首个差异偏移:", diff, "期望", want[diff:diff + 4].hex() if diff >= 0 else "-",
                  "实际", got[diff:diff + 4].hex() if diff >= 0 else "-")
        return same
    print("   回读失败 rc=%d" % rc2)
    return False


def main():
    PATTERN.write_bytes(bytes(range(256)) * 16)   # 4096 字节测试图样
    if not wait_download():
        return 1

    test_write("stub", None)
    test_write("ROM loader (--no-stub)", ["--no-stub"])
    print("\n诊断结束")
    return 0


if __name__ == "__main__":
    sys.exit(main())
