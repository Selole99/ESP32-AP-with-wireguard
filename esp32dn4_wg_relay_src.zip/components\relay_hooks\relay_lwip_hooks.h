/*
 * relay_lwip_hooks.h - 通过 ESP_IDF_LWIP_HOOK_FILENAME 注入到 lwIP 的钩子声明
 *
 * 作用：把 AP 客户端 TCP SYN 里的 MSS 钳到隧道 MTU 能承受的值。
 * 不这么做的话：手机 MTU 1500 → 服务器按 1460 发数据 → 超过隧道 MTU 1280
 * → lwIP 转发时丢弃（ICMP "需要分片" 又带不上 MTU 字段，手机不会退回小 MSS）
 * → 现象就是"WiFi 连上了但网页一直转圈"。
 */
#pragma once

#include "lwip/pbuf.h"
#include "lwip/netif.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 返回值：0 = 继续正常处理；非 0 = 已被钩子消费（本实现永远返回 0） */
int relay_ip4_input_hook(struct pbuf *p, struct netif *inp);

#ifdef __cplusplus
}
#endif

#define LWIP_HOOK_IP4_INPUT(pbuf, input_netif) relay_ip4_input_hook(pbuf, input_netif)
