/*
 * main.c - ESP32-DN4 WireGuard 中继固件
 *
 * 启动顺序（严格串行，满足"先取时间、再接隧道"的要求）：
 *   1. NVS / 配置载入
 *   2. 起 AP(APSTA)，手机连上后打开 http://192.168.4.1/
 *   3. 浏览器页面自动上送本机时间 -> settimeofday()
 *   4. STA 连上游 WiFi -> 拿到 IP
 *   5. time_ready && sta_ip -> WireGuard 上线 -> 默认路由切到 wg netif
 *   6. 打开 AP 侧 NAPT，客户端流量 => wg netif => 对端 => 互联网
 *   7. WG 掉线 -> 关闭 NAPT（防泄漏），自动重连
 */
#include <string.h>
#include <stdio.h>

#include "sdkconfig.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "app_config.h"
#include "config_store.h"
#include "wifi_mgr.h"
#include "wg_mgr.h"
#include "time_sync.h"
#include "web_server.h"
#include "esp_ota_ops.h"

static const char *TAG = "main";

/* 延迟应用 AP 侧 DNS（dhcps 需要重启才能带上新选项） */
static void dns_task(void *arg)
{
    (void)arg;
    vTaskDelay(pdMS_TO_TICKS(3000));
    const relay_cfg_t *c = config_get();
    wifi_mgr_ap_set_dns(c->wg.dns1, c->wg.dns2);
    vTaskDelete(NULL);
}

/* 状态机：把上面 4~7 步串起来 */
static void supervisor_task(void *arg)
{
    (void)arg;
    int  last_ip_gen = -1;
    int  last_wg_state = -1;
    int64_t last_hint = 0;

    for (;;) {
        const relay_cfg_t *c = config_get();

        /* --- 上游链路变化：WG 需要重建 --- */
        if (wifi_mgr_sta_has_ip()) {
            int gen = wifi_mgr_ip_generation();
            if (last_ip_gen >= 0 && gen != last_ip_gen && wg_mgr_is_up()) {
                ESP_LOGW(TAG, "upstream ip changed, restarting tunnel");
                wg_mgr_stop();
            }
            last_ip_gen = gen;
        } else {
            if (wg_mgr_is_up()) {
                ESP_LOGW(TAG, "upstream link lost, tearing down tunnel");
                wg_mgr_stop();
            }
            last_ip_gen = -1;
        }

        /* --- 时间兜底（默认关闭） --- */
        if (!time_sync_ready() && wifi_mgr_sta_has_ip() && c->time.allow_sntp_bootstrap) {
            time_sync_bootstrap_sntp();
        }

        /* --- 自动拉起隧道 --- */
        if (!wg_mgr_is_up() && !wg_mgr_user_stopped() && c->wg.enabled) {
            if (!time_sync_ready()) {
                if (esp_timer_get_time() - last_hint > 10 * 1000 * 1000LL) {
                    ESP_LOGW(TAG, "waiting for time sync: open http://" RELAY_AP_IP "/ on your phone");
                    last_hint = esp_timer_get_time();
                }
            } else if (wifi_mgr_sta_has_ip()) {
                wg_mgr_start();
            }
        }

        /* --- 定时重启（uptime 达到设定小时数即重启，重启后重新计时） --- */
        uint8_t rebh = config_reboot_hours();
        if (rebh > 0 &&
            esp_timer_get_time() >= (int64_t)rebh * 3600LL * 1000000LL) {
            ESP_LOGW(TAG, "scheduled reboot: uptime reached %u h", (unsigned)rebh);
            esp_restart();
        }

        /* --- NAPT 跟隧道状态严格绑定（防泄漏） ---
         * 必须和 wifi_mgr 里的真实状态比较：重启隧道时 wg_restart_task
         * 会直接关一次 NAPT，本地缓存会漏掉这次变化，导致再也开不回来。 */
        bool want_napt = wg_mgr_is_up();
        if (want_napt != wifi_mgr_napt_on()) {
            if (wifi_mgr_napt_set(want_napt) == ESP_OK) {
                ESP_LOGI(TAG, "NAT forwarding %s", want_napt ? "ENABLED" : "DISABLED");
            }
        }

        int st = (int)wg_mgr_state();
        if (st != last_wg_state) {
            ESP_LOGI(TAG, "wg state -> %s (%s)", wg_mgr_state_str(), wg_mgr_last_error());
            last_wg_state = st;
        }

        /* 每 5 秒报一次握手状态，便于判断"接口起来了但没握手" */
        wg_mgr_traffic_tick();
        static int64_t last_hs_log = 0;
        if (wg_mgr_is_up() && esp_timer_get_time() - last_hs_log > 5 * 1000 * 1000LL) {
            last_hs_log = esp_timer_get_time();
            char tip[20];
            uint32_t tx_bps = 0, rx_bps = 0;
            wg_mgr_traffic_rates(&tx_bps, &rx_bps);
            wg_mgr_tunnel_ip(tip, sizeof(tip));
            ESP_LOGI(TAG, "wg: handshake=%s tunnel=%s napt=%s clients=%d rx=%uKB/s tx=%uKB/s",
                     wg_mgr_peer_up() ? "OK" : "none", tip,
                     wifi_mgr_napt_on() ? "on" : "off", wifi_mgr_ap_client_count(),
                     (unsigned)(rx_bps / 1024), (unsigned)(tx_bps / 1024));
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "==== ESP32 WireGuard relay boot ====");

    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "erasing nvs: %s", esp_err_to_name(err));
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    ESP_ERROR_CHECK(config_init());
    time_sync_init();
    wg_mgr_init();

    wifi_mgr_init();

    ESP_ERROR_CHECK(web_server_start());

    xTaskCreatePinnedToCore(dns_task, "ap_dns", 3072, NULL, 3, NULL, 1);
    xTaskCreatePinnedToCore(supervisor_task, "supervisor", 4096, NULL, 4, NULL, 1);

    /* OTA 回滚保护：等到 WiFi/HTTP/监管任务都起来了再确认新固件有效；
     * 若新固件在初始化阶段崩溃，bootloader 会回滚到旧分区。 */
    esp_ota_mark_app_valid_cancel_rollback();

    ESP_LOGI(TAG, "ready: join '%s' then open http://" RELAY_AP_IP "/",
             config_get()->ap.ssid);
}
