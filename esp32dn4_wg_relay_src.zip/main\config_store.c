/*
 * config_store.c - 配置持久化（NVS blob）
 */
#include <string.h>
#include "sdkconfig.h"
#include "esp_log.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "config_store.h"

static const char *TAG = "cfg";
static const char *NVS_NS  = "relaycfg";
static const char *NVS_KEY = "cfg";

static relay_cfg_t     s_cfg;
static SemaphoreHandle_t s_lock;

static void set_defaults(relay_cfg_t *c)
{
    memset(c, 0, sizeof(*c));
    c->magic = RELAY_CFG_MAGIC;
    c->ver   = RELAY_CFG_VER;

    /* 上游 WiFi 空 = 未配置 */
    c->sta.ssid[0] = '\0';
    c->sta.auth    = RELAY_AUTH_WPA2_PSK;

    relay_str_copy(c->ap.ssid, sizeof(c->ap.ssid), RELAY_AP_DEF_SSID);
    relay_str_copy(c->ap.pass, sizeof(c->ap.pass), RELAY_AP_DEF_PASS);
    c->ap.auth    = RELAY_AUTH_WPA2_PSK;
    c->ap.channel = RELAY_AP_DEF_CHAN;
    c->ap.hidden  = false;
    c->ap.max_conn = 8;

    c->wg.enabled   = true;
    c->wg.priv[0]   = '\0';
    c->wg.peer_pub[0] = '\0';
    /* 全零 PSK（base64）—— 用于避免部分 wireguard-lwip 版本对空 PSK 的处理问题 */
    relay_str_copy(c->wg.psk, sizeof(c->wg.psk),
                   "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
    c->wg.endpoint[0] = '\0';
    relay_str_copy(c->wg.tunnel_ip, sizeof(c->wg.tunnel_ip), "10.66.66.3");
    relay_str_copy(c->wg.tunnel_mask, sizeof(c->wg.tunnel_mask), "255.255.255.0");
    c->wg.listen_port = 51820;
    c->wg.keepalive   = 25;
    c->wg.mtu         = 1280;
    relay_str_copy(c->wg.dns1, sizeof(c->wg.dns1), "1.1.1.1");
    relay_str_copy(c->wg.dns2, sizeof(c->wg.dns2), "8.8.8.8");

    relay_str_copy(c->time.tz, sizeof(c->time.tz), "CST-8");
    c->time.allow_sntp_bootstrap = false;
}

static esp_err_t load_from_nvs(void)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READONLY, &h);
    if (err == ESP_ERR_NVS_NOT_FOUND) {
        ESP_LOGW(TAG, "no saved config, using defaults");
        set_defaults(&s_cfg);
        return ESP_ERR_NOT_FOUND;
    }
    if (err != ESP_OK) return err;

    relay_cfg_t tmp = { 0 };
    size_t len = sizeof(tmp);
    err = nvs_get_blob(h, NVS_KEY, &tmp, &len);
    nvs_close(h);

    if (err != ESP_OK || len != sizeof(tmp) || tmp.magic != RELAY_CFG_MAGIC) {
        ESP_LOGW(TAG, "config invalid (err=%s len=%u magic=%08x), reset to defaults",
                 esp_err_to_name(err), (unsigned)len, (unsigned)tmp.magic);
        set_defaults(&s_cfg);
        return ESP_ERR_INVALID_STATE;
    }
    s_cfg = tmp;
    return ESP_OK;
}

esp_err_t config_init(void)
{
    if (s_lock == NULL) {
        s_lock = xSemaphoreCreateMutex();
        if (s_lock == NULL) return ESP_ERR_NO_MEM;
    }
    esp_err_t err = load_from_nvs();
    if (err != ESP_OK) {
        /* 首次启动：立刻写一次，避免后续 NVS 键不存在 */
        config_save(&s_cfg);
    }
    ESP_LOGI(TAG, "loaded: ap='%s' sta='%s' wg=%s ep='%s'",
             s_cfg.ap.ssid,
             s_cfg.sta.ssid[0] ? s_cfg.sta.ssid : "<none>",
             s_cfg.wg.enabled ? "on" : "off",
             s_cfg.wg.endpoint);
    return ESP_OK;
}

const relay_cfg_t *config_get(void)
{
    return &s_cfg;
}

esp_err_t config_save(const relay_cfg_t *cfg)
{
    if (cfg == NULL) return ESP_ERR_INVALID_ARG;

    xSemaphoreTake(s_lock, portMAX_DELAY);
    s_cfg = *cfg;
    s_cfg.magic = RELAY_CFG_MAGIC;
    s_cfg.ver   = RELAY_CFG_VER;

    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
    if (err == ESP_OK) {
        err = nvs_set_blob(h, NVS_KEY, &s_cfg, sizeof(s_cfg));
        if (err == ESP_OK) err = nvs_commit(h);
        nvs_close(h);
    }
    xSemaphoreGive(s_lock);

    if (err != ESP_OK) ESP_LOGE(TAG, "save failed: %s", esp_err_to_name(err));
    return err;
}

esp_err_t config_update_sta(const relay_sta_cfg_t *sta)
{
    relay_cfg_t c = s_cfg;
    c.sta = *sta;
    return config_save(&c);
}

esp_err_t config_update_ap(const relay_ap_cfg_t *ap)
{
    relay_cfg_t c = s_cfg;
    c.ap = *ap;
    return config_save(&c);
}

esp_err_t config_update_wg(const relay_wg_cfg_t *wg)
{
    relay_cfg_t c = s_cfg;
    c.wg = *wg;
    return config_save(&c);
}

esp_err_t config_update_time(const relay_time_cfg_t *t)
{
    relay_cfg_t c = s_cfg;
    c.time = *t;
    return config_save(&c);
}

esp_err_t config_reset(void)
{
    relay_cfg_t c;
    set_defaults(&c);
    return config_save(&c);
}

uint8_t config_reboot_hours(void)
{
    nvs_handle_t h;
    uint8_t hours = 0;
    if (nvs_open(NVS_NS, NVS_READONLY, &h) == ESP_OK) {
        nvs_get_u8(h, "rebh", &hours);   /* 键不存在时保持 0 */
        nvs_close(h);
    }
    return hours;
}

esp_err_t config_set_reboot_hours(uint8_t hours)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_set_u8(h, "rebh", hours);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    ESP_LOGI(TAG, "scheduled reboot interval -> %u h", (unsigned)hours);
    return err;
}
