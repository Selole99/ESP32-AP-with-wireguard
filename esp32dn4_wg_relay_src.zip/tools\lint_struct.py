#!/usr/bin/env python3
"""轻量结构检查：括号/引号平衡、头文件声明与实现对照、常见笔误。
不依赖 ESP-IDF，仅做静态粗查。"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / "main"

C_FILES = sorted(p for p in MAIN.glob("*.c"))
H_FILES = sorted(p for p in MAIN.glob("*.h"))

def strip_code(src: str) -> str:
    """去掉注释与字符串，便于做括号平衡检查"""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '/' and i + 1 < n and src[i+1] == '/':
            while i < n and src[i] != '\n':
                i += 1
        elif c == '/' and i + 1 < n and src[i+1] == '*':
            i += 2
            while i + 1 < n and not (src[i] == '*' and src[i+1] == '/'):
                i += 1
            i += 2
        elif c in '"\'':
            q = c
            i += 1
            while i < n:
                if src[i] == '\\':
                    i += 2
                    continue
                if src[i] == q:
                    i += 1
                    break
                i += 1
        else:
            out.append(c)
            i += 1
    return ''.join(out)

problems = []

for f in C_FILES + H_FILES:
    src = f.read_text(encoding='utf-8', errors='replace')
    code = strip_code(src)
    for open_c, close_c, name in (('{', '}', 'brace'), ('(', ')', 'paren'), ('[', ']', 'bracket')):
        d = code.count(open_c) - code.count(close_c)
        if d != 0:
            problems.append(f"{f.name}: {name} unbalanced ({d:+d})")
    if '\t' in src:
        problems.append(f"{f.name}: contains tab")

# 头文件里声明的函数是否都有实现（跨所有 .c）
decls = {}
for h in H_FILES:
    for m in re.finditer(r'^\s*(?:esp_err_t|void|bool|int|int8_t|time_t|time_src_t|wg_state_t|const char \*)\s+(\w+)\s*\(', h.read_text(encoding='utf-8'), re.M):
        decls[m.group(1)] = h.name

impl = ""
for c in C_FILES:
    impl += c.read_text(encoding='utf-8')

for name, hname in decls.items():
    if not re.search(r'\b' + re.escape(name) + r'\s*\([^;]*\)\s*\{', impl, re.S):
        # 允许 static inline
        problems.append(f"declared in {hname} but no definition: {name}")

# 粗略检查：本地头文件（本工程的 .h）是否都能找到；系统头不做校验
own = {h.name for h in H_FILES}
for c in C_FILES:
    src = c.read_text(encoding='utf-8')
    for m in re.finditer(r'#include\s+"([^"]+)"', src):
        inc = m.group(1)
        if inc not in own:
            continue
        if not (MAIN / inc).exists():
            problems.append(f"{c.name}: local include missing -> {inc}")

print(f"checked {len(C_FILES)} .c / {len(H_FILES)} .h, {len(decls)} header decls")
if problems:
    print("\nISSUES:")
    for p in problems:
        print(" -", p)
    sys.exit(1)
print("OK: no structural issues detected")
