@echo off
rem Build and flash classic ESP32 (COM9). ASCII only, no UTF-8 comments.
setlocal
rem Git Bash/MSYS injects MSYSTEM which ESP-IDF export.bat rejects; clear it.
set "MSYSTEM="
call C:\esp\esp-idf\export.bat
if errorlevel 1 goto :fail
cd /d "%~dp0.."
idf.py build
if errorlevel 1 goto :fail
idf.py -p COM9 flash
if errorlevel 1 goto :fail
echo BUILD_FLASH_OK
exit /b 0
:fail
echo BUILD_FLASH_FAILED
exit /b 1
