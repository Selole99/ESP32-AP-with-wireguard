/*
 * app_config.h - ESP32-DN4 WireGuard 中继固件：全局配置定义
 */
#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"

#define RELAY_CFG_MAGIC 0x52454C59u /* 'RELY' */
#define RELAY_CFG_VER   3

/* AP 默认值 */
#define RELAY_AP_DEF_SSID  "ESP32-RELAY"
#define RELAY_AP_DEF_PASS  "relay12345"
#define RELAY_AP_DEF_CHAN  6
#define RELAY_AP_IP        "192.168.4.1"

/* 字段长度 */
#define RELAY_SSID_MAX  32
#define RELAY_PASS_MAX  64
#define RELAY_KEY_MAX   48
#define RELAY_EP_MAX    96
#define RELAY_TZ_MAX    40
#define RELAY_IP_MAX    20

/*
 * 认证方式枚举 —— 数值与 esp_wifi 的 wifi_auth_mode_t 完全一致，直接强转使用。
 */
typedef enum {
    RELAY_AUTH_OPEN          = 0,
    RELAY_AUTH_WEP           = 1,
    RELAY_AUTH_WPA_PSK       = 2,
    RELAY_AUTH_WPA2_PSK      = 3,
    RELAY_AUTH_WPA_WPA2_PSK  = 4,
    RELAY_AUTH_WPA2_ENTERPRISE = 5,
    RELAY_AUTH_WPA3_PSK      = 6,
    RELAY_AUTH_WPA2_WPA3_PSK = 7,
} relay_auth_t;

/* 上游（要中继的）WiFi */
typedef struct {
    char    ssid[RELAY_SSID_MAX + 1];
    char    pass[RELAY_PASS_MAX + 1];
    uint8_t auth;               /* relay_auth_t */
    char    bssid[18];          /* 可选，空串=任意 */
} relay_sta_cfg_t;

/* 自己发出的热点 */
typedef struct {
    char    ssid[RELAY_SSID_MAX + 1];
    char    pass[RELAY_PASS_MAX + 1];
    uint8_t auth;               /* relay_auth_t */
    uint8_t channel;
    bool    hidden;
    uint8_t max_conn;
} relay_ap_cfg_t;

/* WireGuard */
typedef struct {
    bool     enabled;           /* 是否自动上线 */
    char     priv[RELAY_KEY_MAX];       /* 本机私钥 base64 */
    char     peer_pub[RELAY_KEY_MAX];   /* 对端公钥 base64 */
    char     psk[RELAY_KEY_MAX];        /* 预共享密钥 base64，可为全 0 */
    char     endpoint[RELAY_EP_MAX];    /* host:port 或 ip:port */
    char     tunnel_ip[RELAY_IP_MAX];   /* 隧道接口自身地址（=NAT 后源地址），如 10.66.66.2 */
    char     tunnel_mask[RELAY_IP_MAX]; /* 隧道接口掩码，如 255.255.255.0 */
    uint16_t listen_port;
    uint16_t keepalive;
    uint16_t mtu;
    char     dns1[RELAY_IP_MAX];
    char     dns2[RELAY_IP_MAX];
} relay_wg_cfg_t;

/* 时间 */
typedef struct {
    char tz[RELAY_TZ_MAX];      /* POSIX TZ，如 "CST-8" / "UTC-8" */
    bool allow_sntp_bootstrap;  /* 时间未同步时是否允许先用 SNTP 兜底（会在 WG 前产生明文 NTP 流量） */
} relay_time_cfg_t;

typedef struct {
    uint32_t         magic;
    uint16_t         ver;
    uint16_t         _pad;
    relay_sta_cfg_t  sta;
    relay_ap_cfg_t   ap;
    relay_wg_cfg_t   wg;
    relay_time_cfg_t time;
} relay_cfg_t;

/* 扫描结果条目 */
typedef struct {
    char    ssid[RELAY_SSID_MAX + 1];
    uint8_t bssid[6];
    int8_t  rssi;
    uint8_t channel;
    uint8_t auth;               /* relay_auth_t */
} relay_scan_entry_t;

#define RELAY_SCAN_MAX 32

/* 工具 */
static inline void relay_str_copy(char *dst, size_t n, const char *src)
{
    if (n == 0) return;
    if (src == NULL) { dst[0] = '\0'; return; }
    size_t i = 0;
    for (; i + 1 < n && src[i]; ++i) dst[i] = src[i];
    dst[i] = '\0';
}
