#pragma once

#include "app_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 初始化：填充默认值并尝试从 NVS 载入 */
esp_err_t config_init(void);

/* 取得当前配置指针（只读语义；修改请用 config_update_*） */
const relay_cfg_t *config_get(void);

/* 全量替换 + 落盘 */
esp_err_t config_save(const relay_cfg_t *cfg);

/* 局部修改（加锁复制-修改-保存） */
esp_err_t config_update_sta(const relay_sta_cfg_t *sta);
esp_err_t config_update_ap(const relay_ap_cfg_t *ap);
esp_err_t config_update_wg(const relay_wg_cfg_t *wg);
esp_err_t config_update_time(const relay_time_cfg_t *t);

/* 恢复出厂 */
esp_err_t config_reset(void);

/* 定时重启间隔（小时，0=关闭）。独立 NVS 键，不进主配置结构，
 * 避免结构体变长导致旧配置 blob 校验失败被重置。 */
uint8_t    config_reboot_hours(void);
esp_err_t  config_set_reboot_hours(uint8_t hours);

#ifdef __cplusplus
}
#endif
