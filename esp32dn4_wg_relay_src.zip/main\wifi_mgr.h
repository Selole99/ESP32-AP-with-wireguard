#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
#include "app_config.h"

#ifdef __cplusplus
extern "C" {
#endif

void wifi_mgr_init(void);

/* 应用 AP / STA 配置（AP 变更需要重启射频，调用方负责 esp_restart） */
esp_err_t wifi_mgr_apply_ap(const relay_ap_cfg_t *ap);
esp_err_t wifi_mgr_apply_sta(const relay_sta_cfg_t *sta);

bool wifi_mgr_sta_connected(void);
bool wifi_mgr_sta_has_ip(void);
int8_t wifi_mgr_sta_rssi(void);
void wifi_mgr_sta_ip(char *buf, size_t n);
int  wifi_mgr_ap_client_count(void);
int8_t wifi_mgr_ap_client_rssi(void);
esp_err_t wifi_mgr_sta_radio(char *phy, size_t n, uint8_t *ch, uint8_t *bw);

/* 每次拿到新 IP 自增，供上层检测链路变化（WG 需要重建） */
int  wifi_mgr_ip_generation(void);

/* 扫描，返回条目数（阻塞，约 2~3 秒） */
esp_err_t wifi_mgr_scan(relay_scan_entry_t *out, int max, int *count);

/* NAT 转发开关（AP netif 上做 NAPT，出口 = 当前默认 netif = WireGuard） */
esp_err_t wifi_mgr_napt_set(bool on);
bool wifi_mgr_napt_on(void);

/* 把 DNS 下发给 AP 客户端 */
esp_err_t wifi_mgr_ap_set_dns(const char *dns1, const char *dns2);

#ifdef __cplusplus
}
#endif
