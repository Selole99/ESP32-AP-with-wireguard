#!/usr/bin/env python3
"""用 ROM loader（--no-stub，绕过 flasher stub）烧写，最 tolerant 的模式。

用法: python tools/flash_rom.py COM9 [460800] [等下载模式秒数]
"""
import subprocess
import sys
import time
from pathlib import Path

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM9"
BAUD = sys.argv[2] if len(sys.argv) > 2 else "460800"
TIMEOUT = int(sys.argv[3]) if len(sys.argv) > 3 else 1200
PY = sys.executable

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
APP = BUILD / "esp32dn4_wg_relay.bin"
BOOT = BUILD / "bootloader" / "bootloader.bin"
PT = BUILD / "partition_table" / "partition-table.bin"

BASE = [PY, "-m", "esptool", "--chip", "esp32", "-p", PORT, "-b", BAUD,
        "--before", "no_reset", "--after", "no_reset", "--no-stub"]


def run(args):
    r = subprocess.run(BASE + args, capture_output=True, text=True)
    return r.returncode, ((r.stdout or "") + (r.stderr or ""))


def wait_dl():
    print("等待下载模式（按住 BOOT → 点 RST 或 拔插 USB）...")
    t0 = time.time()
    while time.time() - t0 < TIMEOUT:
        rc, out = run(["flash_id"])
        if "Chip is ESP32" in out:
            print("connected (ROM loader):",
                  [l.strip() for l in out.splitlines() if "Chip is" in l][0])
            return True
        time.sleep(2)
    return False


def main():
    app = APP.read_bytes()
    if not wait_dl():
        print("超时")
        return 1

    print("\n测试写 4KB ...")
    rc, out = run(["write_flash", "--flash_mode", "dio", "--flash_size", "4MB",
                   "0x9000", "C:/esp/_t4k.bin"])
    print("  rc=%d" % rc, [l.strip()[:90] for l in out.splitlines() if l.strip()][-2:])
    if rc != 0:
        print("ROM loader 也写不进 -> flash 硬件问题")
        return 1

    print("\n正式烧写 (ROM loader, %d bytes) ..." % len(app))
    rc, out = run(["write_flash", "--flash_mode", "dio", "--flash_size", "4MB",
                   "--flash_freq", "40m",
                   "0x1000", str(BOOT),
                   "0x8000", str(PT),
                   "0x10000", str(APP)])
    for l in out.splitlines():
        s = l.strip()
        if s and any(k in s for k in ("Wrote", "Writing at", "fatal", "error", "Error")):
            print("  ", s[:110])
    print("rc =", rc)
    if rc == 0:
        print("== ROM loader 写入完成 ==")
        run(["run"])
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
