﻿# 烧写到 ESP32-DN4（默认 COM9）
#   .\flash.ps1                 # 编译(如无产物) + 烧写 COM9
#   .\flash.ps1 -Port COM9 -Monitor
#   .\flash.ps1 -Erase          # 全片擦除后再烧（会清空所有配置）

param(
    [string]$Port    = "COM9",
    [int]   $Baud    = 921600,
    [switch]$Monitor,
    [switch]$Erase,
    [switch]$SkipBuild,
    [string]$IdfPath = ""
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$env:MSYSTEM = ""

if ($IdfPath) { $env:RELAY_IDF_PATH = $IdfPath }
. (Join-Path $root "tools\idf.ps1")

Push-Location $root
try {
    # 先确认串口真的存在（插拔/驱动换了编号时给出明确提示）
    try {
        $ports = [System.IO.Ports.SerialPort]::GetPortNames()
        if ($ports -and ($ports -notcontains $Port)) {
            Write-Host "[flash] 警告：当前系统没有 $Port，现有串口: $($ports -join ', ')" -ForegroundColor Yellow
            Write-Host "        用 -Port 指定正确的那个，例如：.\flash.ps1 -Port $($ports[0])" -ForegroundColor Yellow
        } elseif ($ports) {
            Write-Host "[flash] 串口 $Port 已就绪" -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "[flash] 串口枚举失败（忽略，继续）" -ForegroundColor DarkGray
    }

    if ($Erase) {
        Write-Host "[flash] 全片擦除 $Port" -ForegroundColor Yellow
        idf.py -p $Port erase-flash
    }

    if (-not $SkipBuild) {
        $bin = "build\esp32dn4_wg_relay.bin"
        if (-not (Test-Path $bin)) {
            Write-Host "[flash] 无产物，先编译" -ForegroundColor Cyan
            if (-not (Test-Path "sdkconfig")) { idf.py set-target esp32 }
            idf.py build
            if ($LASTEXITCODE -ne 0) { throw "build failed" }
        }
    }

    Write-Host "[flash] 烧写 -> $Port @ $Baud" -ForegroundColor Cyan
    idf.py -p $Port -b $Baud flash
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "烧写失败。若是 'Wrong boot mode detected (0x13)' / 'Failed to connect'：" -ForegroundColor Yellow
        Write-Host "  1) 按住板上的 BOOT(IO0) 不放，按一下 RST/EN，松开 RST，再松开 BOOT" -ForegroundColor Yellow
        Write-Host "  2) 立刻重跑：.\flash.ps1 -Port $Port" -ForegroundColor Yellow
        Write-Host "  3) 若仍失败，降速：.\flash.ps1 -Port $Port -Baud 115200" -ForegroundColor Yellow
        Write-Host "  4) 关掉占用串口的程序（串口监视器 / idf.py monitor / 其它烧写工具）" -ForegroundColor Yellow
        throw "flash failed ($LASTEXITCODE)"
    }

    Write-Host ""
    Write-Host "烧写完成。手机/电脑连接热点后打开 http://192.168.4.1/" -ForegroundColor Green
    Write-Host ""

    if ($Monitor) {
        idf.py -p $Port monitor
    }
}
finally {
    Pop-Location
}
